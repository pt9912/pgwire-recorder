# Slice slice-harness-randform-stelle-und-lesart: Die Stelle einer Nachricht in der Folge ist eine Randform, und wer „Lesart“ in §7 schreibt, hält an

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.
Übernimmt ein anderer Slice den Gegenstand oder entfällt er, geht diese Datei
aus `open/` oder `next/` nach `done/` — §7 nennt in der Zeile `Gegenstand:`
Kennung oder Grund, die Liefer-Punkte der DoD bleiben leer
(§Ein Slice, dessen Gegenstand ein anderer übernimmt).

**Welle:** ohne Welle. Die Closure-Bedingung ist die DoD dieses Slice. Eingesammelt wird er von der nächsten Welle-Closure. Angelegt am 2026-10-15 nach Entscheidung des Nutzers vom selben Tag („ja deine Vorschläge“ auf die beiden Regeländerungen aus dem Register von `BEO-REPO/spec-randform-erst-im-review-entschieden` und `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben`); eingeordnet in `next/`, weil er mit einer Stelle in der Reihenfolge eingeplant ist (§4 *Start*, Drift-Log der Roadmap; die Stelle ist Empfehlung des Planners).

**Bezug:** kein Anspruch des Produkts — der Slice ändert Regeln des Harness. Bindung an das Register: `BEO-REPO/spec-randform-erst-im-review-entschieden` (Auslöser dieses Slice: `slice-v1-abschluss-verbindungsende-format`, F-1; `slice-v1-abschluss-protokollrand`, V-1) und `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben` (18×); Regelstellen: `AGENTS.md` §3.12 (seit slice-harness-randformen-vor-code) und `.claude/commands/implement-slice.md` Randform-Rückgabe (seit slice-harness-blackbox-kern). Keine aktive ADR.

**Berührte Spec-Stellen:** —

**Verantwortlich:** pt9912

**Autor:** Planner. **Datum:** 2026-10-15.

---

## 1. Ziel und Abgrenzung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Zwei Lücken der Randform-Regel schließen, die das Register mehrfach zählt: (1) `AGENTS.md` §3.12 und die Prüfung des Architect (`.claude/agents/architect.md`, Absatz *Randformen eines neuen Vertrags*) nennen die **Stelle einer Nachricht in der Folge** als Randform: Enthält ein Vertrag eine Nachricht, die eine Folge beendet oder ersetzt (Ende, `ready_for_query`, `sync`), nennt §6 je Nachrichtenart die zulässigen Stellen (Anfang, Mitte, direkt vor dem Ende, letzte Gruppe, nicht letzte Gruppe) und je Stelle eine Entscheidung, die Spezifikation trägt sie; dazu die **Reihenfolge mehrerer Ablehnungsgründe** in einer Folge im selben Absatz. (2) `.claude/commands/implement-slice.md` (Randform-Rückgabe) sagt dem Implementer: Wer beim Schreiben von §7 „Lesart“, „Auslegung“ oder „§6 nennt nicht“ formuliert, hat eine Randform gefunden und hält an; das Vermerken in §7 ersetzt die Rückgabe nicht.

**Wortlaut und Entscheidung des Nutzers.** Der Nutzer hat am 2026-10-15 die beiden Regeländerungen bestätigt („ja deine Vorschläge“). Der Wortlaut in §3 ist der gelieferte, nach diesen Vorschlägen; die sprachlichen Abweichungen vom Entwurf des Planners nennt §7. Ändert jemand ihn inhaltlich (andere Stellen in der Aufzählung, anderer Satz zu §7), legt er die Fassung dem Nutzer vor und committet erst nach dessen Antwort; bis dahin ist die Abweichung eine Empfehlung.

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- Ein Sensor, der „Lesart“ oder „Auslegung“ in §7 eines Plans findet, oder einer, der die Tabelle Nachricht × Stelle in §6 prüft — anderer Vorgang (Werkzeug statt Regel), und ein Grep auf Wörter ist unscharf (Treffer in Zitaten, Fehlstellen bei Umschreibung); der Nutzer hat die Regeländerung ohne Sensor bestätigt. Eine Adresse gibt es nicht; ein Sensor wird erst begründet, wenn das Register ein Auftreten trotz der Regel zählt.
- Die Schätzung des Planners in der Metrik von `AGENTS.md` §3.14 mit Faktor, Schnitt ab 70 % der Marke und Meldeschwelle — gehört `slice-harness-schaetzung-planner-faktor`; er ändert §3.14 und `plan-welle.md`, dieser Slice §3.12, `architect.md` und `implement-slice.md` (Reihenfolge und Konfliktfreiheit: §3).
- Änderung an `.claude/commands/plan-welle.md`, `.claude/agents/planner.md`, `.claude/agents/implementer.md`, `.harness/skills/` (auch `reviewer.md`) — Schicht-Abgrenzung und Größe: Der Planner prüft §6 über den bestehenden Satz zu Randformen in `plan-welle.md` Schritt 6, den die Aufzählung in §3.12 füllt; eine weitere Datei brächte einen weiteren Liefer-Punkt, und die Zeile `plan-welle.md` gehört dem anderen Slice.
- Rückwirkendes Nachziehen der Pläne in `next/` und `open/` um die Tabelle Nachricht × Stelle — Bestand bleibt bewusst stehen: Die Prüfung des Architect vor dem Code geht die Verträge mit Nachrichtenfolge ohnehin durch (`slice-v1-abschluss-verbindungsende-record`, `-replay`, `-sqlite`, `-upstream`, `-einspielen`, `-vergleich`), und die Regel gilt ab dem Commit.
- Änderung der Spezifikation oder der Meldungen zum Verbindungsende — anderer Vorgang: Die Entscheidung der beiden Lesarten aus F-1 liegt in `slice-v1-abschluss-verbindungsende-format-schreiber` bzw. beim Architect.
- Produkt-Code, Gates, Benutzerhandbuch — Schicht-Abgrenzung: Der Slice ändert drei Dokumente des Harness und kein Verhalten des gebauten Binary.

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt: Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan **geändert**, nicht nur ergänzt.

## 2. Definition of Done

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] **Liefer-Punkt 1:** `AGENTS.md` §3.12 trägt den Absatz *Die Stelle einer Nachricht gehört dazu* (Aufzählung der Stellen, eine Entscheidung je Stelle, die Spezifikation trägt sie; Reihenfolge mehrerer Ablehnungsgründe), mit einem Paar Falsch/Richtig (Anlass `slice-v1-abschluss-verbindungsende-format`, F-1), Begründung mit `BEO-REPO/spec-randform-erst-im-review-entschieden` und Retirement-Check mit `seit slice-harness-randform-stelle-und-lesart`; `.claude/agents/architect.md` nennt die Stelle in der Prüfung der Liste aus §6 mit Zeiger auf §3.12, ohne den Absatz zu wiederholen.
- [x] **Liefer-Punkt 2:** `.claude/commands/implement-slice.md` (Randform-Rückgabe) trägt den Satz zu „Lesart“, „Auslegung“ und „§6 nennt nicht“ in §7, mit Zeiger auf `AGENTS.md` §3.12 und dem Herkunfts-Anker `seit slice-harness-randform-stelle-und-lesart`; kein Sensor.
- [x] Kein Wortlaut lockert oder ersetzt eine Zusage von §3.12 oder der Randform-Rückgabe (Beleg: `git diff` der drei Dateien ohne Löschzeile in den bestehenden Regeln, in §7).
- [x] `make gates` grün.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag; Herkunfts-Anker `seit slice-harness-randform-stelle-und-lesart` in `AGENTS.md` §3.12 und in `implement-slice.md` (`liegt in`).
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben: `BEO-REPO/spec-randform-erst-im-review-entschieden` und `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben` von `geplant` auf `verkörpert` (Zielort und Anker); der Zähler folgt den Dateien in `evidence/`, kein Auftreten durch die Lieferung.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen).
- [x] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — im Repo **ohne** Wellen-Betrieb hier geprüft, im Repo **mit** Wellen von der nächsten Welle-Closure (auch für Slices ohne Wellen-Zugehörigkeit).

## 3. Plan (vor Code)

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `AGENTS.md` §3.12 | update (ergänzen) | neuer Absatz *Die Stelle einer Nachricht gehört dazu* nach dem Absatz *Aufrufarten des Treibers*, vor der Begründung; Paar Falsch/Richtig; Begründung und Retirement-Check um den Anlass und `seit slice-harness-randform-stelle-und-lesart` ergänzt |
| `.claude/agents/architect.md` | update | im Absatz *Randformen eines neuen Vertrags*: ein Satz, dass die Prüfung der Liste auch die Stelle jeder Nachricht, die eine Folge beendet oder ersetzt, und die Reihenfolge mehrerer Ablehnungsgründe umfasst (`AGENTS.md` §3.12) |
| `.claude/commands/implement-slice.md` | update | Randform-Rückgabe: ein Satz nach *Auch eine Lesart ist eine Entscheidung* |

**Gelieferter Wortlaut in `AGENTS.md` §3.12** (nach den bestätigten Vorschlägen). Neuer Absatz nach *Aufrufarten des Treibers*:

> **Die Stelle einer Nachricht gehört dazu** (seit slice-harness-randform-stelle-und-lesart, Entscheidung des Nutzers vom 2026-10-15): Enthält ein Vertrag eine Nachricht, die eine Folge beendet oder ersetzt (Ende, `ready_for_query`, `sync`), nennt §6 je Nachrichtenart die zulässigen Stellen in der Folge (Anfang, Mitte, direkt vor dem Ende, letzte Gruppe, nicht letzte Gruppe) und je Stelle eine Entscheidung; die Spezifikation trägt sie. Kann eine Folge aus mehreren Gründen abgelehnt werden, nennt §6 die Reihenfolge der Gründe, und die Spezifikation bindet sie.
>
> **Falsch:** §6 nennt die Nachrichten `ready_for_query` und `connection_closed`, aber nicht, ob sie vor dem Ende oder mitten in der Folge stehen dürfen; der Implementer entscheidet beide im Code, und das Review findet sie (F-1 in `slice-v1-abschluss-verbindungsende-format`).
> **Richtig:** §6 führt je Nachricht die Stellen auf und zeigt auf die Stelle der Spezifikation, die jede entscheidet; dann folgt der Code.

Begründung (Ergänzung der bestehenden): `BEO-REPO/spec-randform-erst-im-review-entschieden`; Retirement-Check um „für die Stelle einer Nachricht seit slice-harness-randform-stelle-und-lesart“ ergänzt.

**Gelieferter Satz in `.claude/commands/implement-slice.md`** (Randform-Rückgabe, am Ende des Absatzes mit *Lesart, nicht entschieden*): „Schreibst du in §7 „Lesart“, „Auslegung“ oder „§6 nennt nicht“ als eigene Feststellung, hast du eine Randform gefunden und hältst an; ein Vermerk in §7 ersetzt die Rückgabe nicht (`AGENTS.md` §3.12, seit slice-harness-randform-stelle-und-lesart, `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben`).“

**Gelieferter Satz in `.claude/agents/architect.md`**, im Absatz zur Prüfung der Liste aus §6 nach „Fehlt in §6 eine, die der Vertrag hat, meldest du sie dem Planner.“: „Zur Liste gehört die Stelle jeder Nachricht, die eine Folge beendet oder ersetzt, und die Reihenfolge mehrerer Ablehnungsgründe (`AGENTS.md` §3.12, seit slice-harness-randform-stelle-und-lesart).“ Das Melden an den Planner trägt der Satz davor.

**Reihenfolge und Konfliktfreiheit zu `slice-harness-schaetzung-planner-faktor`:** Beide Slices ändern `AGENTS.md` und Dateien unter `.claude/`, aber verschiedene Stellen: dieser §3.12 (`architect.md`, `implement-slice.md`), jener §3.14 und `plan-welle.md`; keine Datei außer `AGENTS.md` ist gemeinsam, und dort liegen die Absätze getrennt (die Textmarken von §3.12 und §3.14 überlappen nicht). Dieser Slice steht in der Reihenfolge vor jenem (Schritt 35b liegt dazwischen, §4); WIP-Limit 1 verhindert parallele Zweige, und die Basis jeder Marke ist der Stand des Hauptzweigs vor dem eigenen Anspruch (hier `88f9c5e`), die Diffs zählen sich also nicht gegenseitig. Jener Slice zählt `architect.md` und `implement-slice.md` in seiner Abgrenzung als „nicht seines“; dieser Slice nimmt sie, ohne dass jener Gegenstand verliert (`grep` nach der Kennung dieses Slice in jenem bleibt leer, weil keine Sendung hin- oder hergeht).

## 4. Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): Dieser Slice steht in der wellenlosen Reihe direkt **vor** `slice-v1-abschluss-verbindungsende-format-schreiber` (Schritt 35b) und damit vor `slice-harness-schaetzung-planner-faktor` (Empfehlung des Planners, nicht entschieden; Drift-Log der Roadmap vom 2026-10-15): Der Anlass F-1 betrifft genau die Verträge zur Nachrichtenfolge, die 35b und die sechs folgenden Slices zum Verbindungsende liefern, und der Architect prüft deren §6 mit der Regel. Der Nutzer kann ihn hinter welle-v1-abschluss legen. WIP-Limit 1. Kein weiterer Slice in `in-progress/`.

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): **Marke mit Metrik** (`AGENTS.md` §3.14): die Summe aus Einfügungen und Löschungen von `git diff --numstat 88f9c5e..<letzter Commit des Slice> -- AGENTS.md .claude`, wobei die Basis `88f9c5e` der Stand des Hauptzweigs vor dem Anspruch ist; **über 100** geht der Slice zurück zur Zerlegung. **Meldeschwelle 80:** Erreicht die Summe 80, hält der Implementer an und meldet dem Planner, bevor er weiterarbeitet. Schätzung des Planners: 30 bis 50, Mitte 40, 40 % der Marke (anwendbar: Absatz mit Falsch/Richtig rund 15 bis 20 Zeilen, zwei Sätze in den Commands je 2 bis 4 Zeilen, Retirement-Check und Begründung 3 bis 6 Zeilen); Faktor Tests zu Produktcode entfällt (kein Code, kein Test).
- `in-progress` → `next`: Die Regel verlangt eine vierte Datei (`plan-welle.md`, `planner.md`, ein Skill) oder einen Sensor — zurück zur Zerlegung (§1).
- `in-progress` → `open`: Der Nutzer lehnt eine inhaltliche Abweichung des Implementers vom Wortlaut ab und hat keine Fassung, die er bestätigen würde — der Slice wartet auf die Entscheidung, ohne dass ein abweichender Wortlaut in `AGENTS.md` steht.

## 5. Closure-Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

DoD vollständig, Review-Report liegt vor, Closure-Notiz mit Lerneintrag geschrieben (geschärfte Regel: `AGENTS.md` §3.12 und `implement-slice.md`, `liegt in`).

## 6. Risiken und offene Punkte

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

**Randformen der Regel** (`AGENTS.md` §3.12; der Slice liefert keinen Vertrag von Code, aber eine Regel, deren Ränder sonst im Einzelfall entschieden werden). Entscheidungsort ist der Wortlaut in `AGENTS.md` §3.12:

- *Reichweite der Aufzählung:* „Anfang, Mitte, direkt vor dem Ende, letzte Gruppe, nicht letzte Gruppe“ ist die Liste der bestätigten Vorschläge; Der Wortlaut in `AGENTS.md` §3.12 verlangt „die zulässigen Stellen“ und je Stelle eine Entscheidung; eine Stelle, die ein Vertrag nicht kennt (etwa „letzte Gruppe“ in einer Folge ohne Gruppen), ist keine zulässige und steht nicht in der Liste. Ob §6 sie ausdrücklich als nicht berührt verneinen muss, sagt der Wortlaut nicht; der Plan entscheidet es nicht über den Wortlaut hinaus (offene Frage an den Orchestrator, Review F-5).
- *Reihenfolge der Ablehnungsgründe:* gilt, wo eine Folge aus mehr als einem Grund abgelehnt werden kann; bei genau einem Grund entfällt sie. Der Wortlaut nennt „Kann eine Folge aus mehreren Gründen abgelehnt werden“ (Anlass `slice-v1-abschluss-protokollrand`, V-1, `_pq_.` vor `PGR-E6003`).
- *„Lesart“ im Zitat:* Der Satz zu §7 gilt für den Text, den der Implementer als eigene Feststellung schreibt; ein Zitat der Spezifikation oder eines Reviews mit dem Wort ist keine Randform. Ein Sensor darauf ist ausgeschlossen (§1).
- *Aufruf-Voraussetzung, Aufrufarten des Treibers:* nicht berührt; der Slice liefert weder Werte über mehrere Aufrufe noch ein Ergebnis, das ein Hook oder Gate glaubt (`AGENTS.md` §3.12).

**Risiken:**

- Die Aufzählung der Stellen ist zu eng oder zu weit (ein Vertrag mit einer Stelle, die sie nicht nennt, bleibt ohne Eintrag in §6) — **Ausgang:** weiter offen: → `BEO-REPO/spec-randform-erst-im-review-entschieden` (ein Auftreten trotz der Regel zählt dort weiter; dazu die offene Frage, ob §6 eine nicht berührte Stelle ausdrücklich verneinen muss, Verify V-2 und Review F-5).
- Der Satz in `implement-slice.md` wird gelesen, aber nicht befolgt, weil kein Sensor ihn prüft; das Review findet die Randform weiter erst nach dem Code — **Ausgang:** weiter offen: → `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben` (Auftreten trotz der Regel zählt weiter; ein Sensor wird erst dann ein Slice, §1).
- Ein Auftreten nach diesem Slice schwächt die Regel oder bestätigt sie — das ist Urteil des Planners beim Retirement-Check (`AGENTS.md` §3.12, §3.14-Muster), nicht des Implementers — **Ausgang:** entfallen: Bis zur Closure steht kein Auftreten nach `95a5bc2` im Register (beide Beobachtungen führen als letztes `slice-v1-abschluss-verbindungsende-format`, vor diesem Slice); der Retirement-Check wird erst bei einem späteren Auftreten gestellt und gehört dann dem Planner.
- Der Slice wächst über Marke oder Meldeschwelle von §4 (drei Dateien, Absatz mit Falsch/Richtig; Schätzung 30 bis 50 gegen Marke 100) — **Ausgang:** entfallen: Gemessen 20 in der Metrik von §4, unter Meldeschwelle 80 und Marke 100; der Slice ist geliefert.

## 7. Closure-Notiz

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<KUERZEL>/<slug>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks). Ging der Gegenstand an einen anderen Slice oder entfiel er, trägt
diese Sektion die Zeile `Gegenstand:` mit Kennung oder Grund und jedes Risiko
aus §6 seinen Ausgang; die Liefer-Punkte der DoD bleiben leer
(`modul-05-planning-harness.md` §Ein Slice, dessen Gegenstand ein anderer
übernimmt).

**Belege des Implementers** (Metrik `git diff --numstat 88f9c5e..HEAD -- AGENTS.md .claude`, vor dem Commit gemessen: `AGENTS.md` 14 + 1, `architect.md` 2 + 0, `implement-slice.md` 3 + 0, Summe 20 gegen Marke 100 und Meldeschwelle 80).

Wortlaut gegenüber dem Entwurf in §3: inhaltlich gleich. Angepasst sind das Idiom der Umgebung (Zeilenumbruch, „die Nachrichten“ im Plural des Falsch-Beispiels, „und die Spezifikation bindet sie“), im Satz für `architect.md` entfällt „fehlt sie, meldest du sie dem Planner“ (der Absatz davor sagt es schon), und im Satz für `implement-slice.md` steht „als eigene Feststellung“ aus der Randform „Lesart im Zitat“ in §6. Die eine gelöschte Zeile in `AGENTS.md` ist das Ende des Retirement-Checks, der um „für die Stelle einer Nachricht seit slice-harness-randform-stelle-und-lesart“ verlängert wird (`slice-harness-gate-kette-schnell?` wird zu `slice-harness-gate-kette-schnell, …?`); keine Zusage ist gelockert.

§3.10: Reine Prosa, kein Test, keine Mutation. Was die Zusagen belegt: Lesen der drei Stellen gegen §1 und §3 (Aufzählung der fünf Stellen, Entscheidung je Stelle, Spezifikation trägt sie, Reihenfolge der Gründe, Falsch/Richtig, Begründung mit `BEO-REPO/spec-randform-erst-im-review-entschieden`, Retirement-Check, Zeiger im Architect, Satz in `implement-slice.md`) und `make docs-check` für auflösende Verweise. 

Läufe: erster voller `make gates`: Exit 2, rot `test-postgres-versionen-gegenprobe` bei der Mutation `p7-int-treiber`, zusätzlich rot `p7-sigTERM-skript`; der Diff berührt weder Gate noch Gegenprobe. Einzellauf des Gates: grün. Zweiter voller `make gates`: Exit 0. `make docs-check`: 809 Dateien, 0 Befunde. Das ist nach dem Register-Stand von `BEO-REPO/gegenprobe-mutation-faerbt-zusaetzlichen-fall-zeitabhaengig` (2 Auftreten) das dritte Auftreten der Flanke `p7-int-treiber`; das Register führt sie mit dem Slice `slice-harness-gegenprobe-matrix-p7-flanke` (Closure-Zeile *Beobachtungs-Register* unten).

**Closure (Planner, 2026-10-15).** Review `e8d930a`: 0 HIGH, 0 MEDIUM, 2 LOW (F-1, F-2), 4 INFO; F-1 und F-2 behoben in `d53f830`. Verifikation `305cf57`: **PASS mit Befunden**, 0 HIGH, 0 MEDIUM, 1 LOW (V-1), 3 INFO (V-2 bis V-4).

- **Was hat funktioniert:** Beide Regeländerungen kamen mit dem bestätigten Wortlaut in drei Dateien, 20 Zeilen in der Metrik von §4 gegen Marke 100; die Verifikation prüfte jede Zusage des Beschlusses als eigenes Satzglied (Tabelle *Trägt der Wortlaut die DoD*), weil Prosa keine Mutation kennt. Der Plan zählte vorab Liefer-Punkte, Schichten und die Abgrenzung zu `slice-harness-schaetzung-planner-faktor`; keine Datei außer `AGENTS.md` ist beiden gemeinsam.
- **Was ging anders als geplant:** (1) DoD-Punkt 3 („Beleg: `git diff` ohne Löschzeile in den bestehenden Regeln, in §7“) ist wörtlich nicht erbringbar: Der Diff hat genau eine Löschzeile, das verlängerte Ende des Retirement-Checks in `AGENTS.md` (`slice-harness-gate-kette-schnell?` wird `slice-harness-gate-kette-schnell, … seit slice-harness-randform-stelle-und-lesart?`). In der Sache ist er erfüllt (`git diff 88f9c5e..HEAD -- AGENTS.md .claude | grep '^-[^-]'` findet nur diese Zeile; keine Bedingung wird enger, keine Zusage entfällt, Review-Negativbefund und Verify V-1). Der Punkt ist mit dieser Begründung abgehakt, der Wortlaut der DoD bleibt stehen (V-1). (2) Der Plan in §3 trug nach der Lieferung noch den Entwurf (Review F-2) und §6 eine Randform ohne Träger im Wortlaut (F-1); beides behoben in `d53f830`. Das letzte Wort „Entwurf“ in §6 (Verify V-3) ist hier bereinigt.
- **Steering-Loop-Eintrag:** Geschärfte Regel: `AGENTS.md` §3.12 nennt die Stelle jeder Nachricht, die eine Folge beendet oder ersetzt (Anfang, Mitte, direkt vor dem Ende, letzte Gruppe, nicht letzte Gruppe, je Stelle eine Entscheidung in der Spezifikation) und die Reihenfolge mehrerer Ablehnungsgründe, und `implement-slice.md` sagt, dass „Lesart“, „Auslegung“ oder „§6 nennt nicht“ in §7 eine Randform ist und der Vermerk die Rückgabe nicht ersetzt — liegt in `AGENTS.md §3.12` und `.claude/commands/implement-slice.md` Randform-Rückgabe (Zeiger im Architect: `.claude/agents/architect.md`). Auslöser: `BEO-REPO/spec-randform-erst-im-review-entschieden` (über 3×, zuletzt `slice-v1-abschluss-protokollrand` V-1 und `slice-v1-abschluss-verbindungsende-format` F-1) und `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben` (18×).
- **Sicherheit der Aussage:** Ob die Regel wirkt, zeigt erst das Register: ein Auftreten nach `95a5bc2` trotz der Regel wäre ihr Retirement-Check (Urteil des Planners), ein Ausbleiben bei den sechs Verträgen zum Verbindungsende bestätigt sie. Kein Sensor (Entscheidung des Nutzers vom 2026-10-15).
- **Beobachtungs-Register (`../observations/`):** `BEO-REPO/spec-randform-erst-im-review-entschieden` und `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben` von `geplant` auf `verkörpert` (Zielort und Anker `seit slice-harness-randform-stelle-und-lesart`), der Zähler folgt den Dateien in `evidence/` und steigt durch die Lieferung nicht. `BEO-REPO/plan-folgt-korrektur-nicht`: `evidence/slice-harness-randform-stelle-und-lesart.md` ergänzt (Review F-2, Verify V-3; wiederkehrende Finding-Klasse aus dem Review, Regel `AGENTS.md` §3.9 bleibt). `BEO-REPO/gegenprobe-mutation-faerbt-zusaetzlichen-fall-zeitabhaengig`: `evidence/slice-harness-randform-stelle-und-lesart.md` ergänzt, Zähler 3, Schwelle erreicht, Stand `geplant` mit `slice-harness-gegenprobe-matrix-p7-flanke` (Commit `fa7f491`). Die Flanke ist keine Folge dieser Lieferung (der Slice berührt Gate und Gegenprobe nicht) und steht nicht unter den Risiken.
- **Folge-Slices:** `slice-harness-gegenprobe-matrix-p7-flanke` (Ursache der Kopplung `p7-int-treiber` zu den TERM-Fällen von `p7-sig`) — ist eine Datei in `open/`, Priorisierung offen (Entscheidung des Nutzers).
- **Risiken aus §6:** Aufzählung zu eng oder zu weit: weiter offen → `BEO-REPO/spec-randform-erst-im-review-entschieden`. Satz ohne Sensor nicht befolgt: weiter offen → `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben`. Auftreten nach dem Slice: entfallen (kein Auftreten nach `95a5bc2`). Wachstum über Marke: entfallen (20 gegen 100).
- **Drei Paarungen:** (a) Anker: `seit slice-harness-randform-stelle-und-lesart` steht in `AGENTS.md` (Absatz *Die Stelle einer Nachricht gehört dazu* Zeile 339 und Retirement-Check Zeile 358), in `.claude/commands/implement-slice.md` (Zeilen 148 bis 149) und in `.claude/agents/architect.md` (Zeilen 28 bis 29); `grep -n "randform-stelle-und-lesart"` findet alle. (b) Folge-Slice: `slice-harness-gegenprobe-matrix-p7-flanke` existiert in `open/` und nimmt an: §1 *Sendung der drei Geber* und die DoD (Liefer-Punkt 1) nennen die Kennung dieses Gebers, `grep -n "slice-harness-randform-stelle-und-lesart"` findet sie dort (Zeilen 15, 47, 68); der Nehmer ist nachgezählt (§8 dort: 2 Liefer-Punkte, 2 Schichten). (c) Register: die vier Einträge oben tragen ihre Zeilen und `evidence/`-Dateien.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

**Vorgelagert — Sub-Area-Wahl prüfen:** Das Repo deklariert eine Sub-Area für das gesamte Repo (`harness/conventions.md`, Kürzel `REPO`); der Slice berührt sie, die Schwelle ≥ 2 von 3 Achsen ist nicht berührt.

**Vorgelagert — offene Beobachtungen sichten:** Register durchgegangen (gemergter Stand, 2026-10-15). Treffer in der Sub-Area `REPO`: `BEO-REPO/spec-randform-erst-im-review-entschieden` und `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben` sind der Auslöser und durch Entscheidung des Nutzers vom 2026-10-15 diesem Slice als `geplant` zugewiesen (beide stehen über 3×; mit diesem Slice erreicht keine Beobachtung eine Schwelle neu). `BEO-REPO/plan-folgt-korrektur-nicht` und `BEO-REPO/zusage-im-kommentar-weiter-als-pruefung` werden nicht berührt: Der Slice ändert drei Regeldokumente und trägt die Änderungen in §1, §3 und §6 nach (`AGENTS.md` §3.9). Kein weiterer Treffer.

Nachgezählt (Planner, 2026-10-15, `AGENTS.md` §3.13): Liefer-Punkte: 2 (`AGENTS.md` §3.12 mit dem Satz in `architect.md`; `implement-slice.md`). Schichten: zwei, das Briefing (`AGENTS.md`) und die Rollen- und Command-Artefakte (`.claude/agents/`, `.claude/commands/`); Planung (Register, Plan, Roadmap) zählt keine Schicht; kein Produkt-Code, keine Nutzer-Doku. Der Slice nimmt die Zuweisung beider Beobachtungen aus dem Register an (Adresse nimmt an: §1 schließt sie nicht aus, die DoD führt sie) und trägt keine Sendung in einen anderen Nehmer ein: keine Nachzählung bei einem anderen Slice. Gemessen in der Metrik von §4: 20 (Stand vor dem Commit); Schätzung des Planners: 30 bis 50 (Mitte 40, 40 % der Marke 100); Faktor Tests zu Produktcode entfällt (kein Test); der Plan liegt unter 70 % der Marke und bleibt ungeteilt.

**Modus-Begründungsblock:** alle berührten Sub-Areas GF.
