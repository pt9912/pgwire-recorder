# Slice slice-v1-abschluss-protokollrand: Protokollversion und Protokollrand

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.
Übernimmt ein anderer Slice den Gegenstand oder entfällt er, geht diese Datei
aus `open/` oder `next/` nach `done/` — §7 nennt in der Zeile `Gegenstand:`
Kennung oder Grund, die Liefer-Punkte der DoD bleiben leer
(§Ein Slice, dessen Gegenstand ein anderer übernimmt).

**Welle:** welle-v1-abschluss.

**Bezug:** [`LH-FA-05`](../../../../spec/lastenheft.md#lh-fa-05--simple-query-protocol), [`LH-RB-02`](../../../../spec/lastenheft.md#lh-rb-02--einsatzumgebung)

**Berührte Spec-Stellen:** `LH-FA-05.b` · `LH-FA-05.c` · `LH-FA-05.e` · `LH-FA-12.a` · `LH-FA-18.a` · `LH-FA-23.a` · `SPEC-029` · `SPEC-026` · `ARC-006` · `ARC-007`

**Verantwortlich:** pt9912
**Autor:** pt9912. **Datum:** 2026-10-03.

---

## 1. Ziel und Abgrenzung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Jede Zeile der Tabelle in `LH-FA-05.e` (Protokollversion, `SSLRequest`, `GSSENCRequest`, `CancelRequest`, erste Nachricht und Startnachricht am Rand, unbekannte Sonderanfrage, `COPY`, `FunctionCall`, `NotificationResponse`, `LISTEN`/`NOTIFY`) ist am gebauten Binary durch einen Test belegt, und die Auswahl der Anmelde-Nachrichten, die das Replay emuliert, ist fest und geprüft (`LH-FA-05.b`, *Replay*).

**Stand beim Start (Planner, 2026-10-15, gelesen gegen den Code):** Das Verhalten der meisten Zeilen liefern Vorgänger-Slices und Bestand (`TestSSLUndGSSMitN`, `TestAndereProtokollversion`, `TestCancelRequest`, `TestFremdeErsteNachricht`, `TestVerbindungOhneNachricht`, `TestUnbekannteSonderanfrage`, `TestNichtUnterstuetzteNachricht`, `TestE2ERecordSSLAbgelehnt`, `TestE2ERecordNichtUnterstuetzt`, `TestE2ERecordFremdeAnfrage`, `TestE2ERecordHalbeStartnachricht`; die Anmeldung im Record liefern `slice-v1-abschluss-anmeldung` und `-einspielen-anmeldung`, TLS `slice-v1-abschluss-tls-client`, die Zusage der Versionen `slice-v1-abschluss-postgres-versionen-zusage`). Der Slice ist deshalb vor allem Inventur und Lückenschluss: Der Implementer legt zuerst je Zeile und je Pfad (Happy/Boundary/Negative) und je Modus (`record`, `replay`) die Deckung offen (Abdeckungs-Deklarationen in `docs/user/abdeckung-*.md`) und schließt die Lücken. Vermutete Lücken, ungeprüft: keine Abdeckungs-Deklaration beim Test der unbekannten Sonderanfrage; kein E2E-Test für die andere Protokollversion, `FunctionCall`, `NotificationResponse` und `LISTEN`/`NOTIFY` gegen einen echten Server; die Zeile *Verbindung ohne erste Nachricht* als TCP-Probe im E2E; die Zeilen im Modus `replay`.

**Entscheidungen des Architect vor dem Code (2026-10-15):** Die Randformen aus §6 sind in der Spezifikation entschieden, in `LH-FA-05.e` (*Randformen des Protokollrands*, Zeilen der Tabelle berichtigt) und `LH-FA-05.b` (*Auswahl im Replay*); eine Folge-ADR ist nicht nötig. Zwei Entscheidungen ändern Produkt-Code und gehören zu den Zeilen *Startnachricht am Rand* und *Teilnachrichten*: Ein Startparameter mit dem Präfix `_pq_.` ist in beiden Modi `PGR-E6001` und vor dem Aufbau zum Upstream (heute antwortet der Server mit `NegotiateProtocolVersion`, was `record` als `PGR-E6001` meldet, und `replay` bedient den Client ohne Antwort), und eine vollständig gelesene Client-Nachricht mit ungültigem Rumpf (Sonde: `p` ohne Nullbyte) ist `PGR-E6001` statt eines stillen Endes des Clients. Die Zeile `LISTEN`/`NOTIFY` ist berichtigt (Sonde gegen die Images 14, 17 und 18 über das gebaute Binary: `LISTEN x; NOTIFY x` in einer Session und in einer Anfrage, und eine Benachrichtigung einer zweiten Session sind `PGR-E6001`; `LISTEN` allein und `NOTIFY` allein werden aufgezeichnet). **Zählung der Verbindungen (Architect, 2026-10-15, Rückgabe F-2 des Reviews):** Eine Verbindung zählt (Replay: verbraucht eine Session; Record: Annahme) erst, wenn ihre Startnachricht gelesen und angenommen ist; eine vom Recorder abgelehnte (Version außer 3.0 `PGR-E6002`, nicht lesbarer Rumpf, `_pq_.`, unverschlüsselt trotz TLS-Pflicht `PGR-E6003`) zählt nicht. Das ist der heutige Code (`annehmen` vor dem Aufbau) und vereinbar mit `LH-FA-12.a` (das Lastenheft nennt "Verbindung", die Startnachricht ist Wortlaut der Spezifikation); Lastenheft und Code bleiben unverändert, die Spezifikation (*Randformen des Protokollrands*, *Angenommene Verbindung*, *Zählung der Verbindungen*, *Zuordnung bei `connection`*) ist angeglichen, der Rückverweis in `LH-FA-05.b` zeigt auf *Startnachricht 3.0* (F-3). Jede Zeile der Tabelle ist im Test an das Ausbleiben einer verbrauchten Session gebunden, soweit die Fälle schon laufen; ein Test, der nach einer abgelehnten Verbindung (`_pq_.`) die nächste reguläre Verbindung die Session 1 erhalten lässt, ist die Mutation, die die Zusage fängt (Implementer, falls nicht vorhanden).

**Umgesetzt (Implementer, 2026-10-15):** Zwei Änderungen am PGWire-Adapter, beide nach `LH-FA-05.e` (*Randformen des Protokollrands*): Ein Parameter mit dem Präfix `_pq_.` in der Startnachricht ist in beiden Modi `PGR-E6001`, vor der Prüfung auf TLS (diese Reihenfolge entschied der Code; der Architect trug sie am 2026-10-15 in die Spezifikation nach, Verifikation V-1) und vor dem Aufbau zum Upstream (`server.go`); ein Leser (`leser.go`) kennzeichnet das Ende des Datenstroms der Client-Verbindung, und ein vollständig gelesener Rumpf, den die Bibliothek nicht liest, ist `PGR-E6001` statt des stillen Endes, auch in der Anmeldung. Der Upstream-Adapter bekommt Tests, keinen Code. Tests: `server_protokollrand_test.go` (Zeilen der Tabelle in beiden Modi, mit und ohne TLS, über rohe Bytes), `upstream_protokollrand_test.go` (Serverantworten) und `protokollrand_e2e_test.go` (gebautes Binary, PostgreSQL 17). Nacharbeit nach dem Review (Implementer, 2026-10-15): `TestProtokollrandPruefreihenfolge` (erst Länge, dann Code; der Rest eines abgelehnten Codes wird nicht gelesen), `TestProtokollrandAbgelehnteVerbindungZaehltNicht` (Zählung der Verbindungen, `LH-FA-05.e`) und die E2E-Zeile *Rumpf nicht lesbar*; die TCP-Probe im E2E läuft über 0 bis 7 Byte; der Kommentar von `startup` ist neu gesetzt, sonst kein Produkt-Code. Offen für den Nutzer bleiben die zwei Fragen aus §6 (Standard: nein); nichts davon ist umgesetzt.

**Übernommen aus `slice-v1-abschluss-cancel-ohne-schluessel` und `slice-v1-abschluss-postgres-versionen`** (dort je §1, Abgrenzung; der Geber ist in `slice-v1-abschluss-postgres-versionen-matrix` und `slice-v1-abschluss-postgres-versionen-zusage` aufgegangen, die Abgrenzung steht in `slice-v1-abschluss-postgres-versionen-matrix` §1): der übrige Protokollrand und die Tests der Tabelle in `LH-FA-05.e`; das sind Ziel und DoD-Punkt 1 oben.

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- Benutzerhandbuch und `README.md` — Doku-Folge-Slice `slice-v1-abschluss-protokollrand-doku` (dort §1 und DoD), direkt hinter diesem Slice in derselben Welle (`AGENTS.md` §3.11, §3.13; Entscheidung des Nutzers vom 2026-10-10): Mit der Dokumentation als eigener Schicht läge dieser Plan über zwei Schichten. Zwischen beiden Slices hinkt das Handbuch dem Binary hinterher; ein Release liegt nicht dazwischen.
- Extended-Query-Nachrichten — bereits Gegenstand von welle-extended-query; hier nur der Protokollrand. Die Zeile der Tabelle (*unterstützt*) gilt mit den vorhandenen Tests dieser Welle als belegt und bekommt hier keinen neuen.
- `CancelRequest` mit 12 Byte (ohne Schlüssel) — `slice-v1-abschluss-cancel-ohne-schluessel` (welle-v1-nachtrag; setzt diesen Slice voraus, dort §1 und DoD): Die Zeile der Tabelle ist hier mit der Länge 16 belegt; die Länge 12 lehnt die PGWire-Bibliothek heute ab und ist dort Gegenstand.
- Die TLS-Hälfte der Zeile `SSLRequest` (*mit Zertifikat und Schlüssel angenommen*) und die Anmeldung im Record — Bestand aus `slice-v1-abschluss-tls-client` und `slice-v1-abschluss-anmeldung` (`done/`): Die Tests liegen dort; dieser Slice fügt keinen hinzu und ändert nichts an ihnen.
- Eine Aushandlung der Protokollversion (`NegotiateProtocolVersion`, Version 3.2) und eine Änderung der Liste der PostgreSQL-Hauptversionen — ein anderer Vorgang mit eigener Anforderung bzw. Gegenstand der Matrix (`slice-v1-abschluss-postgres-versionen-matrix`, `done/`): `LH-FA-05.e` lehnt jede andere Startversion als 3.0 mit `PGR-E6002` ab.
- Weitere emulierte Authentifizierungsverfahren im Replay (Passwort, MD5, SCRAM) — wären ein neuer Funktionsumfang statt der Festlegung des vorhandenen; v1 ist keine Sicherheitsgrenze (`LH-FA-05.b`). Wünscht der Nutzer sie, ist das eine Entscheidung vor dem Start (§6).
- Produkt-Code, der kein Verhalten einer Tabellenzeile oder des Replay-Handshakes berührt — Schicht-Abgrenzung: Die Tests dieses Slice sind überwiegend Tests von Bestand; ein Befund außerhalb der Zeilen geht als Befund an den Planner.

## 2. Definition of Done

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] [`LH-FA-05`](../../../../spec/lastenheft.md#lh-fa-05--simple-query-protocol): Jede Zeile der Tabelle in `LH-FA-05.e` ist durch einen Test belegt (Happy/Boundary/Negative); je Zeile weist die Deckung (`make abdeckung`) den Test nach, und wo eine Zeile in beiden Modi gilt, ist `replay` mit einem Fall belegt oder die Grenze steht in der Spezifikation. Die Zeilen *Extended-Query-Nachrichten* und die TLS-Hälfte von `SSLRequest` zählen mit ihren vorhandenen Tests (§1).
- [x] Der Replay-Handshake emuliert eine feste Auswahl von Authentifizierungsnachrichten, die die Spezifikation nennt (`LH-FA-05.b`, *Replay*; Entscheidung des Architect vor dem Code, §6), und ein Test belegt sie samt Randformen aus §6; der Handshake für den Go-Client im Standardmodus stammt aus `slice-extended-query-replay`. Die Dokumentation der Auswahl im Handbuch liefert `slice-v1-abschluss-protokollrand-doku`.
- [x] `make gates` grün.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben oder „keine Beobachtung angefallen" in §7 notiert.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen).
- [x] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen.
## 3. Plan (vor Code)

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `internal/adapters/driving/pgwire` | update | `_pq_.` in der Startnachricht, Leser für das Ende des Datenstroms (`leser.go`, Test `leser_test.go`), Tests der Tabelle, der Prüfreihenfolge der ersten Nachricht, der Zählung abgelehnter Verbindungen und des Replay-Handshakes in beiden Modi |
| `internal/adapters/driven/postgres` | nur Tests, kein Code | `CopyInResponse`, `CopyOutResponse`, `CopyBothResponse` und `NotificationResponse` als Serverantwort nicht unterstützt (Test in `toResponse` und im Aufbau) |
| `test/integration` | update | E2E-Fälle gegen einen echten Server und das gebaute Binary für die Zeilen ohne E2E; keine Schicht des Hexagons |
| `docs/user/abdeckung-*.md` | update (`make abdeckung`) | erzeugte Tabellen; keine Schicht (`slice-v1-abschluss-protokollrand-doku` §1) |

Die Anmeldung im Record ist Bestand (`slice-v1-abschluss-anmeldung`); der Zeiger „Authentifizierung gegen den Upstream vermitteln“ des Ursprungsplans entfällt.

## 4. Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): `welle-replay-semantik` ist `done`.

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): **Marke mit Metrik** (`AGENTS.md` §3.14): die Summe aus Einfügungen und Löschungen von `git diff --numstat <Basis>..<letzter Commit des Slice> -- internal test spec docs/user`, wobei die Basis der Commit des Übergangs nach `in-progress/` ist; **über 1400** geht der Slice zurück, **Meldeschwelle 1250** (am 2026-10-15 von 1050 angehoben, siehe Absatz unten) (der Implementer meldet den Stand dem Architect, bevor er weiterarbeitet). Festgesetzt vom Architect am 2026-10-15, angehoben von 1200/900 mit Grund: Die Metrik zählt `spec`, und die Festlegung der Randformen (rund 110 Zeilen in `spec/spezifikation.md`, nach der Basis) liegt im Diff. Schätzung des Architect in dieser Metrik: Spezifikation rund 110, Produkt-Code rund 130 (Parameter `_pq_.`, ungültiger Rumpf, Verdrahtung der Prüfungen), Tests rund 500 bis 700 (das Vier- bis Fünffache des Produktcodes, weil die Tabelle in zwei Modi mit gemeinsamer Hilfsfunktion über rohe Bytes läuft und jede Aufzählung je Element zählt, `AGENTS.md` §3.10), erzeugte Tabellen in `docs/user` rund 40; zusammen 800 bis 1000, Streuung bis 1100. Ein roher Test je Element der Aufzählung in eigener Funktion statt einer tabellengetriebenen mit Hilfsfunktion läge darüber (Vorbild: `slice-v1-abschluss-tls-client` §4). Zweiter Anlass: eine dritte Schicht des Hexagons kommt hinzu (zum Beispiel ein Port oder der Kern), oder ein Schnitt der Zeilen nach Lieferwert (Zeilen des Verbindungsaufbaus; Zeilen der Client-Nachrichten) wird nötig. Nachtrag des Architect vom 2026-10-15 (Empfehlung des Architect, vom Implementer mit 1167 im Arbeitsbaum gemeldet; Marke 1400 unverändert): Die Meldeschwelle steigt von 1050 auf 1250, weil die Überschreitung aus den Review-Findings F-1 und F-2 stammt (Test der Prüfreihenfolge Länge vor Code mit 108 Teilfällen, Test „abgelehnte Verbindung zählt nicht“, E2E-Zeile, TCP-Probe 0 bis 7 Byte, erzeugte Tabellen, +149) und jede dieser Zeilen eine Zusage nach `AGENTS.md` §3.10 trägt (je Element einer Aufzählung ein Fall); Kürzen nähme dem Mutationsbild Fälle, die das Review ausdrücklich verlangte. Eine Rückführung ist nicht nötig: Der Zuwachs liegt in Tests einer Schicht und derselben Tabelle, keine dritte Schicht kommt hinzu, der Diff bleibt in einer Review-Sitzung prüfbar. Die Schätzung der Tests (500 bis 700) lag damit um rund 200 darunter; Faktor Tests zu Produktcode bei Tabellen mit Mutations-Nacharbeit rund 8 statt 4 bis 5. Bei Überschreiten von 1250 meldet der Implementer erneut, bei 1400 geht der Slice zurück.
- `in-progress` → `open` (blockiert): Eine Zeile der Tabelle zeigt am gebauten Binary ein Verhalten, das die Tabelle anders regelt, und die Spezifikation lässt sich nicht berichtigen, ohne das Lastenheft zu ändern — zuerst die Entscheidung des Nutzers (Carveout nur nach ihr).

## 5. Closure-Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

DoD vollständig, Review-Report liegt vor, Closure-Notiz mit Lerneintrag geschrieben.

## 6. Risiken und offene Punkte

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

**Randformen** (`AGENTS.md` §3.12) — für den Architect, jede vor dem ersten Code-Commit in der Spezifikation (Technik-Stratum, `LH-FA-05.b`/`.e`) zu entscheiden oder als genannt und entschieden zu belegen; der Planner hat sie gegen den Code gelesen, entschieden hat er keine. Eine Entscheidung des Architect an der Spezifikation ist keine Schicht dieses Slice (wie in `slice-v1-abschluss-tls-client` §8).

| Randform | Was offen ist |
|---|---|
| *Auswahl im Replay* | `LH-FA-05.b` sagt nur „in der Implementierung gewählt“. Heute sendet `ARC-006` nach der Startnachricht ohne Anforderung `AuthenticationOk` (`server.go`); die Spezifikation soll das als feste Auswahl nennen (Empfehlung des Planners: nur `AuthenticationOk`, keine Anforderung, kein Passwort). Dazu: Verhalten, wenn ein Client trotzdem eine Nachricht `p` sendet; ein Client mit `require_auth`/Channel Binding (Grenze oder Fall); Benutzer und Datenbank der Startnachricht werden nicht geprüft; gleich für `replay` mit und ohne TLS. |
| *Modus je Zeile* | Die Tabelle nennt keinen Modus. Je Zeile: gilt sie in `record`, in `replay` oder in beiden (Cancel, Version, Sonderanfrage, fremde erste Nachricht, `COPY`, `FunctionCall`, `NotificationResponse`)? Die Spezifikation sagt es, der Test folgt. |
| *Protokollversion* | Werte `0`, `2.0`, `3.1`, `3.2`, `4.0`, `65535.x` (Hauptnummer 1234 ist Sonderanfrage, Zeile darunter); die Fehlerantwort nennt `PGR-E6002` in `record` und `replay`; mit und ohne TLS; Länge der Startnachricht unter 8, genau 8, ohne Parameter, ohne abschließendes Nullbyte; Parameter `_pq_.`-Präfix (Protokollerweiterung) und `options` — ob sie `PGR-E6002` auslösen oder durchgehen. |
| *Sonderanfrage mit unbekanntem Code* | Hauptnummer 1234 mit Nebennummer außer 5679, 5680 und 5678; Länge ≠ 8 bei bekanntem Code ist bei `SSLRequest`/`GSSENCRequest` entschieden (`PGR-E6001`, Länge außerhalb `PGR-W3003`), bei `CancelRequest` mit Länge ≠ 16 nicht (Länge 12 gehört `slice-v1-abschluss-cancel-ohne-schluessel`; andere Längen hier benennen). |
| *`GSSENCRequest`* | Antwort `N` in beiden Modi; danach `StartupMessage`, `SSLRequest` oder weiterer `GSSENCRequest` (mehrfach) — Reihenfolgen und Wirkung mit und ohne TLS; Bytes vor dem `N`. |
| *`COPY`-Nachrichten* | je Richtung: Client sendet `CopyData`, `CopyDone` oder `CopyFail` ohne vorangehende `COPY`-Anfrage (`PGR-E6001`, SQLSTATE `0A000`); Server antwortet auf eine `COPY`-Anfrage mit `CopyInResponse`, `CopyOutResponse` oder `CopyBothResponse`; ob die Verbindung zum Upstream mit `Terminate` geschlossen wird; die Session wird nicht aufgezeichnet (`LH-FA-06` Negative). |
| *`FunctionCall`* | als erste Nachricht nach dem Aufbau, mitten im Aufbau, in einer Extended-Sequenz, im `replay`. |
| *`NotificationResponse`* | wann sie eintrifft: mitten in der Antwort einer Anfrage (heute `PGR-E6001` in `toResponse`), im Leerlauf zwischen zwei Anfragen (der Recorder liest erst bei der nächsten Anfrage), im Aufbau (heute `PGR-E6001`); was der Client erhält; was aufgezeichnet wird. |
| *`LISTEN`/`NOTIFY` als `Query`* | **Möglicher Widerspruch in der Tabelle, vor dem Code zu klären:** Die Zeile sagt „wie jede andere Query aufgezeichnet“, die Zeile darüber „`NotificationResponse` nicht unterstützt“. Ein `NOTIFY` auf einen Kanal, den dieselbe Session mit `LISTEN` hört, liefert PostgreSQL der eigenen Verbindung vor `ReadyForQuery` zu (Vermutung des Planners, mit einer Sonde gegen den gepinnten Server zu belegen): Dann wäre die Folge `LISTEN x; NOTIFY x` in einer Session nicht aufgezeichnet, sondern `PGR-E6001`. Der Architect legt die Fälle fest (`LISTEN` allein, `NOTIFY` allein, beides in einer Session, zwei Sessions) und berichtigt die Zeile im Wortlaut (`BEO-REPO/spezifikation-widerspricht-sich-im-wortlaut`, 1×). Das Verhalten hängt nicht von der Serverversion ab (zu belegen gegen 14 und 18, `BEO-REPO/serververhalten-nur-gegen-eine-version-geprueft`, 1×). |
| *Verbindung ohne erste Nachricht / Halbe Startnachricht* | TCP-Probe (Verbindung und sofortiges Schließen, auch mit Reset), 1 bis 7 Bytes, genau 8 Bytes mit Länge über 8; in beiden Modi; mit `--record-empty-sessions` (entschieden in `slice-v1-abschluss-sessions`, hier nur geprüft). |
| *Aufrufart: gleichzeitig* | Eine Zeile gilt unabhängig von anderen Verbindungen; ein Fall mit zwei gleichzeitigen Verbindungen, eine mit Protokollrand und eine regulär — die reguläre bleibt unberührt (keine Zusage über Ordnung zwischen Verbindungen). |

**Entschieden vom Architect (2026-10-15), Ort: `spec/spezifikation.md` `LH-FA-05.e` *Randformen des Protokollrands* (außer der ersten Zeile):**

| Randform | Entscheidung (Kurzform; die Spezifikation trägt den Wortlaut) | Test, den der Implementer schreibt |
|---|---|---|
| *Auswahl im Replay* (`LH-FA-05.b` *Auswahl im Replay*) | fest: `AuthenticationOk` als erste Nachricht ohne Anforderung, kein weiteres Verfahren; Benutzer, Datenbank, Parameter ungeprüft, mit und ohne TLS gleich; Nachricht `p` danach `PGR-E6001`; Client mit `require_auth` oder Channel Binding beendet selbst (Grenze, Sonde mit `psql` 17 und 18: bricht ab) | roher Client: erste Nachricht ist `R` mit Code 0; unbekannter Benutzer wird bedient; `p` → `PGR-E6001`; Ende nach `AuthenticationOk`; je mit und ohne TLS |
| *Modus je Zeile* | alle Zeilen in `record` und `replay`; nur Server-Nachrichten (COPY-Antworten, `NotificationResponse`) nur `record`; Randverbindung beendet nur sich, verbraucht im `replay` keine Session | je Zeile ein Fall in beiden Modi über eine gemeinsame Hilfsfunktion; Fall mit zwei gleichzeitigen Verbindungen in beiden Modi |
| *Protokollversion* | 0.0, 2.0, 3.1, 3.2, 4.0, 65535.x: `PGR-E6002`, beide Modi, vor dem Upstream; Länge 8 genügt; 1234.x ist Sonderanfrage; Rumpf ungültig (Länge 8, Länge 9, ohne abschließendes Nullbyte): `PGR-E6001`; `_pq_.`: `PGR-E6001` (Code-Änderung); `options` wie jeder Parameter | je Wert und je Rumpfform ein Fall und eine Mutation; `_pq_.` in `record` gegen einen nicht erreichbaren Upstream (kein Verbindungsversuch); mit TLS die Version nach der Aushandlung |
| *Reihenfolge `_pq_.` zu `PGR-E6003`* (Architect, 2026-10-15, Rückgabe V-1 der Verifikation) | `PGR-E6001` für `_pq_.` steht vor `PGR-E6003`: eine unverschlüsselte Startnachricht 3.0 mit `_pq_.` an einen Recorder mit TLS-Pflicht ist `PGR-E6001`; Ort: `LH-FA-05.e` *Startnachricht 3.0* und `LH-FA-23.a` *Unverschlüsselte Clients* | `ErweiterungVorKlartext` (belegt den Code und jetzt die Spezifikation); `CancelRequest`: die Bibliothek liest Prozess-ID und Schlüssel, der Recorder wertet sie nicht aus (V-3, nur Wortlaut) |
| *Sonderanfrage mit unbekanntem Code* | 1234 außer 5678 bis 5680: `PGR-E6001`; `CancelRequest` Länge 16 zugesagt, Länge 8 `PGR-E6001`, andere Längen nicht zugesagt (Länge 12: `slice-v1-abschluss-cancel-ohne-schluessel`) | je Nebennummer 5677, 5681 und 1 ein Fall; Länge 8 |
| *`GSSENCRequest`* | `N` in beiden Modi; Folgen aus zwei Anfragen (GSS·GSS, GSS·SSL, SSL·GSS, SSL·SSL) ohne TLS, GSS·SSL mit TLS (Aushandlung); Nachricht hinter der Anfrage vor dem `N` gelesen | je Folge ein Fall; Startnachricht im selben Schreibvorgang wie die Anfrage |
| *`COPY`* | Client-Nachrichten `d`, `c`, `f`: `PGR-E6001`, beide Modi; Server `CopyIn/Out/BothResponse`: `PGR-E6001` in `record`, Session nicht aufgezeichnet, `Terminate` nicht zugesagt | je Nachricht ein Fall (roh); `toResponse` je Antwortart; `COPY … TO STDOUT` als E2E vorhanden |
| *`FunctionCall`* | `PGR-E6001` an jeder Stelle, beide Modi: nach dem Aufbau, in einer Extended-Sequenz (ganze Session verworfen), in der Anmeldung | drei Fälle in `record`, zwei in `replay` |
| *`NotificationResponse`* | vor `ReadyForQuery`: `PGR-E6001`; im Leerlauf: spätestens bei der nächsten Anfrage (Zeitpunkt des Lesens nicht zugesagt); im Aufbau: `PGR-E6001`; nach der letzten Interaktion: kein Fehler | Unit in `toResponse` und im Aufbau; E2E gegen den Server: Leerlauf (zweite Session sendet `NOTIFY`, erste fragt danach) |
| *`LISTEN`/`NOTIFY`* | berichtigt, siehe §1; Version nicht durch Test belegt außer Referenz (Grenze) | E2E: `LISTEN` allein, `NOTIFY` allein (aufgezeichnet), `LISTEN x; NOTIFY x` in einer Anfrage und in zwei Anfragen derselben Session (`PGR-E6001`, nicht aufgezeichnet), zwei Sessions |
| *Teilnachrichten, TCP-Probe* | 1 bis 7 Bytes dann Ende oder Reset: still; 8 Bytes Kopf mit Länge über 8: `PGR-E6001`; Rumpf einer späteren Nachricht ungültig: `PGR-E6001`; Abbruch mitten in einer späteren Nachricht: Ende des Clients | je Form ein Fall (TCP-Probe als E2E, auch mit `--record-empty-sessions`); `p` ohne Nullbyte; Abbruch mitten in einer `Query` |
| *Aufrufart: gleichzeitig* | Verbindungen unabhängig, keine Ordnungszusage | zwei Verbindungen, eine mit Protokollrand, die reguläre unberührt, beide Modi |

**Grenzen der Tests (Implementer, 2026-10-15; Messungen in §7):**

- Ein Reset verwirft beim Server nicht immer die gesendeten Bytes unbeobachtet, aber auch nicht verlässlich: Im Mutanten `bytes-2` blieb die Zeile *2 Bytes, Reset* im Replay grün, die geschlossene Zeile wurde rot. Die Reset-Zeilen belegen, dass der Server still endet; welche Byte-Zahl er sah, belegen die geschlossenen. Reset-Zeilen laufen nur ohne TLS.
- Die Grenze zu `require_auth` ist mit `pgconn` (pgx 5.11) im E2E belegt (`require_auth=scram-sha-256`), nicht mit `psql` 17 und 18; die Sonde des Architect mit `psql` bleibt deren Beleg.
- Kein Mutant bricht nur den Abbruch mitten in einer Nachricht: Der Leser kennzeichnet jedes Ende des Datenstroms gleich, die Bibliothek meldet Abbruch mitten in der Nachricht und zwischen zwei Nachrichten nicht verschieden; die Zeilen *Abbruch mitten in einer Query* und *im Kopf einer Query* sind Gutfälle, rot werden sie zusammen mit *Ende nach dem Aufbau*, wenn der Leser das Ende nicht kennzeichnet.
- Kein Mutant bricht nur *Benachrichtigung nach der letzten Interaktion ist kein Fehler*: Der Record liest bei einfachen Anfragen im Leerlauf nichts vom Upstream; die Zeile wäre nur mit einem Hintergrundleser zu brechen, den es nicht gibt. Der E2E-Fall ist ein Gutfall.
- `NotificationResponse` in einer Extended-Sequenz geht durch dieselbe Abbildung (`toResponse`) wie in einer Anfrage; einen eigenen Test dafür gibt es nicht.
- Die Auswahl im Replay mit TLS ist im Unit-Test (Zeile *Benutzer, Datenbank und Parameter ungeprüft* mit TLS), nicht im E2E belegt.
- *Unverschlüsselt trotz TLS-Pflicht* (`PGR-E6003`) verbraucht keine Session: nur im Unit-Test (`TestProtokollrandAbgelehnteVerbindungZaehltNicht`) belegt, nicht im E2E. Der Unit-Test zählt die geöffneten Sessions; die Session-Nummer, die die nächste reguläre Verbindung erhält, sieht erst das E2E (dort für Version 3.2, Sonderanfrage, `_pq_.` und nicht lesbaren Rumpf).
- `TestLeserEndeDesStroms` (V-4) prüft den Leser mit einem Fake-Reader, der den Fehler liefert; dass der Server die Fehler `io.ErrUnexpectedEOF`, `net.ErrClosed` und `os.ErrDeadlineExceeded` auf einer echten Verbindung erhält, ist nicht gemessen und durch keinen Test über den Server belegt (das Zwangsende prüft die Frist vor `verbindungsende`, `server.go`). Die Zusage des Lesers gilt für die fünf Fehler am Leser, nicht für ihr Auftreten am Server.
- Unter dem Mutanten „`_pq_.`-Prüfung aus“ bleibt `TestE2EProtokollrandBeideModi/record/Parameter__pq_.` grün (V-7): Der echte Server antwortet mit `NegotiateProtocolVersion`, die Aufzeichnung meldet es als `PGR-E6001`. Die Zusage „vor dem Aufbau zum Upstream“ im Record trägt allein `TestE2ERecordErweiterungOhneUpstream`.
- Die Skripte und Rohausgaben der Mutanten liegen im Scratchpad der Sitzung und sind kein Beleg im Repo (V-8); die Zeilen sind aus der Beschreibung der Mutation nachfahrbar. Die Gegenprobe `postgres-versionen-gegenprobe` war im ersten Gate-Lauf der Verifikation einmal rot (`p7-int-treiber`, zeitabhängig) und beim Wiederholen grün; der Slice berührt die Gate-Kette nicht.
- Der E2E-Mutant, der `NotificationResponse` als `NoData` abbildet, bleibt grün und ist am Client nicht zu unterscheiden: Die Aufzeichnung lehnt den Typ ab und liefert denselben Code `PGR-E6001`; der Unit-Test des Adapters (`NotificationResponse/Anfrage`) färbt ihn rot (Messung in §7).

**Fragen an den Nutzer (Empfehlungen des Architect, nicht entschieden; kein Code hängt daran):** (1) Soll `replay` weitere Anmeldeverfahren emulieren (Klartext-Passwort, MD5, SCRAM), damit auch ein Client mit `require_auth` ein Verfahren verlangt? Empfehlung: nein; das wäre neuer Funktionsumfang, v1 ist keine Sicherheitsgrenze (`LH-FA-05.b`), und die feste Auswahl bedient die Treiber ohne diese Anforderung. (2) Soll `record` eine `NotificationResponse` aufzeichnen und `replay` sie wiedergeben (LISTEN/NOTIFY als Anwendungsfall)? Empfehlung: nein in v1; es bräuchte eine Anforderung, ein neues Nachrichtenmuster im Format (Formatversion) und eine Zusage über den Zeitpunkt im Leerlauf, und `SPEC-039` grenzt LISTEN/NOTIFY aus.

Zu jeder Zeile der Tabelle und zu jeder Randform gilt `AGENTS.md` §3.10: eine Mutation, die nur sie bricht, vom Implementer selbst rot gesehen; Aufzählungen (Versionswerte, Längen, Nachrichtenarten) zählen je Element.

**Gebundene Sendungen:** Keine eingegangen (`grep -rn "slice-v1-abschluss-protokollrand" docs/plan/planning/next docs/plan/planning/open` findet nur `-protokollrand-doku` (Folge), `-cancel-ohne-schluessel` und `-verbindungsende-format` (Reihenfolge, kein Gegenstand)). Zeigt sich im Lauf eine Sendung an `slice-v1-abschluss-cancel-ohne-schluessel`, geht sie an den Planner.

**Risiken:**

- Die Inventur findet mehr Lücken als der Plan vermutet, und die Zahl der Tests sprengt Größe oder Review-Sitzung (`BEO-REPO/slice-waechst-durch-uebernahmen`, `BEO-REPO/groesse-erst-in-der-pruefung-des-architect-sichtbar`, verkörpert) — **Ausgang:** offen bis Closure; Gegenmittel: Marke und Meldeschwelle aus §4, Schnitt nach Lieferwert (Zeilen des Aufbaus; Zeilen der Client-Nachrichten).
- `LISTEN`/`NOTIFY` in einer Session ist nach der Sonde nicht aufgezeichnet, und die Zeile der Tabelle muss berichtigt werden (Stand 2026-10-15: Sonde belegt es gegen 14, 17 und 18, Zeile berichtigt, Lastenheft unberührt) — **Ausgang:** offen bis Closure; Gegenmittel: Berichtigung der Zeile als Entscheidung des Architect vor dem Code (§6 oben), kein Eingriff in das Lastenheft nötig; wünscht der Nutzer, dass `NotificationResponse` aufgezeichnet wird, ist das eine neue Anforderung und eine Entscheidung des Nutzers.
- Die Auswahl im Replay genügt einem Treiber nicht, der Anmeldung verlangt (`require_auth`) — **Ausgang:** offen bis Closure; Gegenmittel: Grenze in der Spezifikation nennen (v1 ist keine Sicherheitsgrenze), Fall im Test.

## 7. Closure-Notiz

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<NNN>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks). Ging der Gegenstand an einen anderen Slice oder entfiel er, trägt
diese Sektion die Zeile `Gegenstand:` mit Kennung oder Grund und jedes Risiko
aus §6 seinen Ausgang; die Liefer-Punkte der DoD bleiben leer
(`modul-05-planning-harness.md` §Ein Slice, dessen Gegenstand ein anderer
übernimmt).

### Belege des Implementers (2026-10-15)

**Stand und Größe.** Basis `5c4b3ae`; Commits des Implementers `9d56324`, `0e90cf0`, `f99192a`, `c7e0f97`, `44956ac` und die Nacharbeit nach dem Review (der Commit dieser Zeilen). Metrik aus §4, `git diff --numstat 5c4b3ae..<letzter Commit> -- internal test spec docs/user`: **1172** (Einfügungen 1137, Löschungen 35); vor der Nacharbeit 1018 (Stand `eb6ad8b`, mit den 14 Zeilen der Spezifikation aus der Entscheidung des Architect). Marke 1400 nicht erreicht; die Meldeschwelle 1050 war überschritten, der Architect hat sie auf 1250 angehoben (§4), 1250 ist nicht erreicht. Aufteilung: Spezifikation 123 (Architect), Produkt-Code 117 (`server.go` 63, `leser.go` 50, `tls.go` 4), Tests 903 (`server_protokollrand_test.go` 513, `protokollrand_e2e_test.go` 338, `upstream_protokollrand_test.go` 44, kleine Änderungen an zwei vorhandenen Testdateien 8), erzeugte Tabellen 29. Die Nacharbeit trägt rund 110 Zeilen Unit-Test, 10 Zeilen E2E und 12 Zeilen Tabellen bei; der Kommentar von `startup` (22 Zeilen im Diff) ist neu gesetzt, ohne Wirkung auf die Zahl.

**Läufe** (alle nacheinander, kein paralleler Docker-Lauf; Container, Netze und Volumes der Läufe entfernt):

| Lauf | Stand | Ergebnis | Laufzeit |
|---|---|---|---|
| `make test` (nach den Code-Änderungen, vor den neuen Tests) | Arbeitsbaum | grün | 63 s |
| `make test-integration` mit `PGR_TESTS_1` = die fünf neuen E2E-Tests (Phase 2 rot, weil sie ohne Phase 1 der übrigen Tests läuft; nicht Teil des Belegs) | Arbeitsbaum | die fünf neuen Tests grün | 13 s bis 90 s je Lauf |
| `make lint` | `c7e0f97` | 0 Befunde (vorher 3: `startup` zu komplex nach Zyklomatik und Kognition, `errcheck` im Test; behoben durch `annehmen`) | 16 s |
| `make gates` | `c7e0f97` | grün, Exit 0 (Versionsmatrix 14 bis 18 grün, Stop-Hook-Gegenprobe 139 Fälle) | 12 min 22 s |
| Nacharbeit: `make test-integration` mit `PGR_TESTS_1` = `TestE2EProtokollrandBeideModi` und `TestE2EProtokollrandTCPProbe`, dazu je ein Lauf der zwei E2E-Mutanten (Phase 2 rot ohne Phase 1, nicht Teil des Belegs) | Arbeitsbaum | beide Tests grün, die Mutanten rot | 20 s je Lauf |
| Nacharbeit: `make lint` | Arbeitsbaum | 0 Befunde (vorher 1: `startcodes` als globale Variable, `gochecknoglobals`; zur Funktion geworden) | 16 s |
| Nacharbeit: `make gates` | Arbeitsbaum, Commit dieser Zeilen | grün, Exit 0 (Stop-Hook-Gegenprobe 139 Fälle) | 736 s |
| Nacharbeit zur Verifikation (V-4): `make gates` | Arbeitsbaum mit `leser_test.go` | grün, Exit 0 (Stop-Hook-Gegenprobe 139 Fälle) | über 600 s |

Frühere `make gates` im Lauf waren rot und führten zurück in den Plan (in der Nacharbeit `docs-check`: vier unverlinkte ADR-Kennungen in der Zeile der aktiven ADRs des Review-Reports, verlinkt; `kopf-check`: `LH-FA-12.a` fehlte im Kopf, nachgetragen; `lint`: siehe Zeile): `abdeckung-check` (Tabellen nach neuer Deklaration nicht erneuert; `make abdeckung`), `a-check` (`pgproto3` in `test/integration` ist ein Tech-Leck; die E2E-Tests nutzen die Hilfsfunktionen des Bestands `leseNachricht`, `clientNachricht`, `bisTyp`, `schreibe`) und `lint`.

**Befund vorher und nachher.** Vorher (Basis-Code, nachgestellt durch die Mutanten `pq-weg` und `ende-io-eof-alt`): Ein Parameter `_pq_.` ging an den Upstream; eine Nachricht `p` oder `Parse` ohne Nullbyte endete still als Ende des Clients (in der Anmeldung ebenso). Nachher: beide `PGR-E6001` mit Fehlerantwort, im Record endet die Session als nicht unterstützt und wird nicht aufgezeichnet.

**Mutationstabelle** (Zusage · Mutation · roter Test). „Zeile“ ist eine Zeile der Tabellen in `server_protokollrand_test.go`; jede läuft in {Record, Replay} × {ohne, mit TLS}, also vier Mal, außer wo es anders steht. Mutanten laufen in frischen Kopien des Arbeitsbaums per Bind-Mount (kein Build-Kontext, keine mtime-Falle); Skripte und Rohausgabe liegen im Scratchpad der Sitzung.

| Zusage | Mutation | roter Test (genannte Tests; weitere mitfärbende nicht aufgezählt) |
|---|---|---|
| Parameter `_pq_.` ist `PGR-E6001` | `pq-weg`: Prüfung abgeschaltet | Zeilen `_pq_.`, `_pq_.foo`; `ErweiterungVorKlartext` |
| nur Präfix, kein Teilstring | `pq-contains`: `HasPrefix` → `Contains` | Zeile `_pq_. nicht am Anfang` |
| Präfix mit Punkt | `pq-praefix-ohne-punkt`: `_pq_` | Zeile `_pq_ ohne Punkt` |
| Präfix mit Unterstrich | `pq-praefix-ohne-unterstrich`: `pq_.` | Zeile `pq_. ohne Unterstrich`, dazu `_pq_.`, `_pq_.foo` |
| `_pq_.` vor der Prüfung auf TLS (`PGR-E6001` vor `PGR-E6003`) | `pq-nach-klartext`: Reihenfolge getauscht | `ErweiterungVorKlartext` (1) |
| `_pq_.` vor dem Aufbau zum Upstream | `pq-nach-aufbau`: Prüfung in `handle` nach `oeffne`; E2E `pq-nach-aufbau2`: nach dem Fehlerzweig des Aufbaus | Zeilen `_pq_.`, `_pq_.foo` (Session geöffnet), `ErweiterungVorKlartext`; E2E `TestE2ERecordErweiterungOhneUpstream` (Upstream nicht erreichbar, `PGR-E4002` statt `PGR-E6001`) und `BeideModi/replay/Parameter__pq_.` |
| Version 0.0, 2.0, 3.1, 3.2, 4.0, 65535.1 ist `PGR-E6002` | `version-<v>`: der Wert wird wie 3.0 weitergereicht, je Wert ein Mutant (6) | je die Zeile `Version <v>` in `TestProtokollrandStartnachricht`; gemessen mitgefärbt (Nacharbeit): 0.0, 3.1 und 3.2 färben `TestAndereProtokollversion`, 2.0 dazu `TestTLSRangfolge`, 4.0 dazu `TestAndereProtokollversion`, `TestProtokollrandPruefreihenfolge` und `TestProtokollrandAbgelehnteVerbindungZaehltNicht`, 65535.1 dazu `TestProtokollrandPruefreihenfolge` (der Bestand kennt 65535.1 nicht); E2E für 3.2 `BeideModi/{record,replay}/Version_3.2` |
| Sonderanfrage 5677, 5681, 1 ist `PGR-E6001` | `sonder-<n>`: Verbindung schließt still, je Nebennummer ein Mutant (3) | je die Zeile; bei 1 auch `Gleichzeitig`; E2E für 5677 |
| `CancelRequest` Länge 8 ist `PGR-E6001` | `cancel-laenge-8`: schließt still | Zeile `CancelRequest Länge 8` |
| Rumpf der Startnachricht nicht lesbar: Länge 8, Länge 9, ohne abschließendes Nullbyte, Kopf ohne Rest | `rumpf-laenge-<n>` (8, 9, 13, 40): schließt still | je die eigene Zeile. Der erste Versuch mit Länge 18 färbte jede Startnachricht dieser Länge; die Zeile hat Länge 13 |
| 0 bis 7 Bytes enden still | `bytes-<k>` (0 bis 7): `PGR-E6001` bei k gelesenen Bytes im Peek | je die Zeile `<k> Bytes` und, soweit der Server die Bytes nach dem Reset sah, `<k> Bytes, Reset`; E2E `TCPProbe` für 0 bis 7 |
| CopyData, CopyDone, CopyFail, FunctionCall, Nachricht `p` sind `PGR-E6001` | `nachricht-<typ>`: die Nachricht wirkt wie `Terminate` (5) | je die Zeile (bei FunctionCall beide Zeilen); bei `p` auch `TestAnmeldungAndereNachricht`; E2E für `p` ohne Nullbyte, CopyData, FunctionCall |
| FunctionCall in einer Extended-Sequenz | `functioncall-in-extended`: wirkt nach einem `Parse` wie `Terminate` | Zeile `FunctionCall in einer Extended-Sequenz` (die Zeile `nach dem Aufbau` wird mit rot, weil der Mutant seinen Zustand über Tests hinweg behält) |
| ein Rumpf, den die Bibliothek nicht liest, ist nicht das Ende des Clients | `ende-io-eof-alt`: `verbindungsende` zählt zusätzlich `io.EOF` (das Verhalten der Basis) | Zeilen `Nachricht p ohne Nullbyte`, `Parse ohne Nullbyte`; `TestAnmeldungAndereNachricht/Rumpf ohne Nullbyte`; E2E `BeideModi/{record,replay}/Nachricht_p_ohne_Nullbyte` |
| dasselbe nur im Replay, nur im Record, in der Anmeldung | `replay-lesefehler-still`, `record-lesefehler-still`, `anmeldung-eof-still` | je die Zeilen des einen Modus; die Zeile der Anmeldung |
| Ende des Datenstroms: jeder der fünf Fehler `io.EOF`, `io.ErrUnexpectedEOF`, `net.ErrClosed`, `syscall.ECONNRESET`, `os.ErrDeadlineExceeded` (auch eingepackt) ist das Ende der Client-Verbindung, jeder andere Fehler nicht (V-4) | `leser-ohne-<fehler>`: `errors.Is(err, <fehler>)` durch `(false && …)` ersetzt (5 Mutanten, in der Kopie per Bind-Mount, frisch gefahren); `leser-immer-ende`: `return true \|\| …` | je das Teiltest `TestLeserEndeDesStroms/<fehler>` (nur dieser, gemessen); `leser-immer-ende`: `TestLeserEndeDesStroms/anderer_Fehler` |
| das Ende des Clients ist ohne Meldung | `replay-ende-meldung`, `record-ende-meldung`: `PGR-E6001` auch beim Ende | 21 rote Zeilen im Lauf je Modus (alle mit Ende des Clients); E2E `ReplayAuswahl` |
| `AuthenticationOk` ist die erste Nachricht | `authok-zuletzt`: nach den Antworten des Aufbaus | jede Zeile mit Aufbau (76 rote Zeilen im Lauf), `TestAnmeldungAndereNachricht` |
| jede Folge aus zwei Anfragen (GSS·GSS, GSS·SSL, SSL·GSS, SSL·SSL) | `folge-<a>-<b>`: die Folge beendet die Verbindung (4) | je die Zeile `AnfragenFolgen`; bei GSS·SSL auch `GSSdannSSLMitTLS` |
| Bytes hinter einer Anfrage werden nach dem `N` gelesen | `anfrage-puffer-verworfen`: neuer Leser nach der Anfrage | alle vier Zeilen `AnfragenFolgen` |
| mit TLS ist die Antwort auf GSS `N`, der folgende SSLRequest wird angenommen | `gss-mit-tls-beendet` | `GSSdannSSLMitTLS` |
| die Randverbindung beendet nur sich | `rand-beendet-server`: `Zwangsende` bei gescheitertem Aufbau | `Gleichzeitig` (Unit, 1); E2E 10 rote Zeilen im Lauf |
| eine Verbindung vor dem Aufbau verbraucht im Replay keine Session | `replay-oeffnet-frueh`: `OpenConnection` vor der Startnachricht | 97 rote Zeilen im Lauf (Unit); E2E 8 |
| CopyIn-, CopyOut-, CopyBothResponse und NotificationResponse sind `PGR-E6001`, vor `ReadyForQuery` und im Aufbau | `anfrage-<typ>`: `toResponse` bildet sie ab; `aufbau-<typ>`: der Aufbau überspringt sie (je 4) | je die Zeile `<typ>/Anfrage` beziehungsweise `<typ>/Aufbau` |
| `NotificationResponse` im Leerlauf, in einer Anfrage und in zwei Sessions ist `PGR-E6001` | `notification-uebersprungen` (E2E): `lies` überspringt sie | `ListenNotify/{beides in einer Anfrage, zwei Anfragen derselben Session, zwei Sessions}` |
| Replay prüft Benutzer, Datenbank und `options` nicht | `replay-prueft-benutzer`, `-datenbank`, `-option` (E2E) | `TestE2EReplayAuswahl` (je Mutant) |
| Replay fordert kein Verfahren an | `replay-fordert-passwort` (E2E): `AuthenticationCleartextPassword` vor dem `AuthenticationOk` | `TestE2EReplayAuswahl` |
| Prüfreihenfolge: erst die Länge, dann der Code (je Code: 3.0, 4.0, 65535.1, SSLRequest, GSSENCRequest, CancelRequest, Sonderanfrage 1) | `laenge-ohne-<code>`: `case (laenge < 8 \|\| laenge > maxStartLaenge) && code != <code>:` (7 Mutanten) | je `TestProtokollrandPruefreihenfolge`, Zeilen `<Code>, Länge 4`, `Länge 7`, `Länge 10001`, in beiden Modi und mit und ohne TLS (bei der Ausgabe der ersten Zeilen nur die des eigenen Codes) |
| der Rest einer Startnachricht mit abgelehntem Code wird nicht gelesen (4.0, 65535.1: `PGR-E6002`; Sonderanfrage 1 und 5677: `PGR-E6001` mit "unbekannte Sonderanfrage") | `rest-gelesen-<code>`: der Code wird wie 3.0 an pgproto3 weitergereicht (4 Mutanten) | je die Zeile `<Code>, Länge 40 ohne Rest`, in vier Läufen je Modus und TLS; gemessen (Verifikation V-2) färben weitere: `rest-gelesen-4.0` zusätzlich `TestProtokollrandStartnachricht/Version_4.0` (×4), `TestProtokollrandAbgelehnteVerbindungZaehltNicht/Version_4.0` (×2) und `TestAndereProtokollversion`, `rest-gelesen-65535.1` zusätzlich `TestProtokollrandStartnachricht/Version_65535.1` (×4); für Sonderanfrage 1 und 5677 nicht neu gefahren |
| eine abgelehnte Verbindung zählt nicht und verbraucht keine Session (Version 4.0; Rumpf nicht lesbar; `_pq_.`; unverschlüsselt trotz TLS-Pflicht) | `verbrauch-<fall>`: `OpenConnection` (Replay) beziehungsweise `OpenSession` (Record) unmittelbar vor der Ablehnung (4 Mutanten) | je die Zeilen des eigenen Falls in `TestProtokollrandAbgelehnteVerbindungZaehltNicht`, in beiden Modi (zusätzlich die Zeilen der früheren Tests mit `sessions: 0`) |
| dasselbe am gebauten Binary: Rumpf nicht lesbar, nächste reguläre Verbindung erhält im Replay die erste Session | `verbrauch-rumpf-e2e`: `OpenConnection` vor der Fehlerantwort (nur Replay) | `TestE2EProtokollrandBeideModi/replay/Rumpf_nicht_lesbar`; der Record-Fall bleibt grün, weil die Mutation nur den Replay trifft |
| TCP-Probe mit 0 bis 7 Byte ist kein Fehler (E2E, `--record-empty-sessions`) | `bytes-3-e2e`: bei 3 gepufferten Bytes `PGR-E6001` statt stilles Ende | `TestE2EProtokollrandTCPProbe` (Exit-Code 6 statt 0); mit der früheren Stichprobe 0, 1 und 7 wäre er grün geblieben |

**Nacharbeit zu F-5: die Spalte ist gemessen, soweit die Mutanten wiederholbar waren.** Neu gefahren, volle Suite (Top-Level-Tests): `pq-weg` (rot: `TestProtokollrandStartnachricht`, `TestProtokollrandErweiterungVorKlartext`, `TestProtokollrandAbgelehnteVerbindungZaehltNicht`), `pq-praefix-ohne-unterstrich` (dieselben drei), `pq-contains` und `pq-praefix-ohne-punkt` (nur `TestProtokollrandStartnachricht`), `sonder-5677` (dazu `TestProtokollrandPruefreihenfolge`), `sonder-5681` (nur `TestProtokollrandStartnachricht`), `sonder-1` (dazu `TestProtokollrandPruefreihenfolge`, `TestProtokollrandGleichzeitig`), `cancel-laenge-8` (nur `TestProtokollrandStartnachricht`). Die übrigen Zeilen der Tabelle (die Mutanten dieses Absatzes ausgenommen) sind nicht neu gefahren; ihre Spalte nennt die Tests, die im ersten Lauf rot waren, und behauptet nicht mehr, dass keine weiteren färben.

**Grüne und äquivalente Mutanten, eingeordnet.**

- `pq-contains` war beim ersten Lauf grün (die Zeile `x_pq_.y` fehlte); die Zeile `_pq_. nicht am Anfang` ist die Folge, danach rot.
- `bytes-2`: Die Zeile `2 Bytes, Reset` im Replay blieb grün (die Zeile `2 Bytes` wurde rot); Grenze in §6.
- Der E2E-Lauf von `cancel-laenge-8` bleibt grün: Die Zeile ist nur im Unit-Test; ein E2E-Fall dafür steht nicht in der Tabelle der Entscheidungen (§6, *Sonderanfrage*).
- Der E2E-Lauf von `anfrage-NotificationResponse` (die Abbildung als `NoData`) bleibt grün, **verändert aber das Verhalten nicht beobachtbar am Client**: Gemessen ist die Fehlerantwort `nicht unterstützt [PGR-E6001]: Interaktion 1 nicht in der Form der Aufzeichnung: Antwort-Typ "no_data" unbekannt in einer einfachen Anfrage`; die Aufzeichnung lehnt den Typ ab und liefert denselben Code. Der Unit-Test des Adapters färbt ihn rot (`NotificationResponse/Anfrage`), der E2E-Mutant `notification-uebersprungen` die drei Fälle.
- Kein Mutant bricht nur den Abbruch mitten in einer Nachricht und nur die Benachrichtigung nach der letzten Interaktion: §6, *Grenzen der Tests*.

**Randformen und Lesarten.** Eine Randform war im Code entschieden: die Reihenfolge `PGR-E6001` (Parameter `_pq_.`) vor `PGR-E6003`. Sie stand beim Code-Commit in keiner Stelle der Spezifikation (Verifikation V-1; `AGENTS.md` §3.12); der Architect hat sie am 2026-10-15 in `LH-FA-05.e` *Startnachricht 3.0* und `LH-FA-23.a` *Unverschlüsselte Clients* nachgetragen (Drift-Log, Rückgabe V-1; Zeile in §6). `ErweiterungVorKlartext` belegt den Code und jetzt die Spezifikation. Sonst wurde keine Randform im Code entschieden. Die Zusage zum `CancelRequest` lautet jetzt „leitet beides nicht weiter und wertet es nicht aus“ (V-3): Die Bibliothek liest Prozess-ID und Schlüssel (deshalb lehnt sie Länge 12 ab); im Code und in den Tests steht keine Aussage „liest beides nicht“ zum `CancelRequest`. Die Meldung zur Erweiterung nennt den Namen des Parameters nicht.

**Durchsicht der Quantoren.** Handbuch und `README.md` sind nicht berührt (`slice-v1-abschluss-protokollrand-doku`); Kommentar und Deklarationen der neuen Tests sagen nur zu, was ein Test belegt. Die Deklaration von `TestAnmeldungAndereNachricht` nennt den Rumpf ohne Nullbyte. Treffer in Kommentaren: keiner zu ändern.

**Für die Closure (Planner).** Die Tabelle in `LH-FA-05.e` ist an diesen Stellen mit Tests belegt: Version, Sonderanfrage, `CancelRequest`, Folgen der Anfragen, Rumpf, `_pq_.`, Nachrichten des Clients, Abbruch, TCP-Probe, Antworten des Servers, `LISTEN`/`NOTIFY`, Auswahl im Replay. Offen für den Nutzer bleiben die zwei Fragen aus §6 (nichts umgesetzt). Beobachtungen aus dem Lauf, die ins Register gehören könnten (Entscheidung beim Planner): (1) `a-check` zeigt ein Tech-Leck in `test/integration` erst im vollen Gate-Lauf, nicht im engeren Sensor `go vet`; (2) das Testgeschirr eines Mutanten, das auf einen festen Text im Quelltext zielt (`rumpf-laenge-18`), färbt mehr als eine Zeile, wenn eine Länge mehrfach vorkommt.

### Closure (Planner, 2026-10-15)

**Review und Verifikation.** Review `bd74c32` (0 HIGH, 2 MEDIUM F-1 und F-2, 3 LOW F-3 bis F-5, 2 INFO F-6 und F-7); Nacharbeit in `0347c8f` und `eccdbcb`, die Zählregel der Verbindungen entschied der Architect in `25f5595` (F-2). Verifikation `9e54e00`: **PASS mit Befunden**, 0 HIGH, 1 MEDIUM (V-1), 3 LOW (V-2 bis V-4, dazu V-5), INFO V-6 bis V-8; DoD-Punkte 1 bis 4 bestätigt, `make gates` im zweiten Lauf grün (Exit 0, 10 min 26 s; der erste war an der zeitabhängigen Gegenprobe `p7-int-treiber` rot, siehe Register). Alle acht Befunde sind abgearbeitet: V-1, V-3 und V-5 durch den Architect und den Planner in `a40b327` und `fdc0c93` (Sätze zur Reihenfolge `_pq_.` vor `PGR-E6003` in `LH-FA-05.e` und `LH-FA-23.a`, Wortlaut des `CancelRequest`, Inhalt der Sendung im Doku-Nehmer), V-2, V-4, V-6 und V-8 in `8049354` (Zeile `rest-gelesen-<code>` gemessen, `TestLeserEndeDesStroms` je Fehler des Datenstroms, Plan §1, §7, §8 berichtigt), V-7 als Grenze in §6. Die Verifikation hat die Nacharbeit zu V-4 nicht erneut als eigenen Bericht abgenommen; den Lauf nach `8049354` fährt der Orchestrator.

**Größe.** 1234 in der Metrik aus §4 (`git diff --numstat 5c4b3ae..8049354 -- internal test spec docs/user`), Meldeschwelle 1250 und Marke 1400 nicht erreicht; Liefer-Punkte 2, Schichten 2 (§8).

**Risiken aus §6 — Ausgang je Risiko** (geschlossene Menge):

| Risiko | Ausgang | Begründung |
|---|---|---|
| Die Inventur findet mehr Lücken, die Zahl der Tests sprengt Größe oder Review-Sitzung | entfallen | Gemessen 1234 unter der Marke 1400, zwei Schichten, der Diff war in einer Review-Sitzung prüfbar (Review und Verifikation haben ihn geprüft); die Meldeschwelle musste angehoben werden, was `BEO-REPO/schaetzung-in-zeilen-unterschaetzt-tests` als Auftreten zählt, nicht als Risiko des Slice. |
| `LISTEN`/`NOTIFY` in einer Session ist nicht aufgezeichnet, die Zeile der Tabelle muss berichtigt werden | entfallen | Der Architect hat die Zeile mit einer Sonde gegen 14, 17 und 18 berichtigt, das Lastenheft blieb unberührt, `TestE2ERecordListenNotify` läuft gegen 17 grün; das Verhalten der übrigen Versionen ist in der Spezifikation Grenze (Zähler `BEO-REPO/serververhalten-nur-gegen-eine-version-geprueft` bleibt 1). Der Wunsch, `NotificationResponse` aufzuzeichnen, ist kein Rest dieses Risikos, sondern Nutzerfrage 2 (unten). |
| Die Auswahl im Replay genügt einem Treiber nicht, der Anmeldung verlangt (`require_auth`) | entfallen | Das Gegenmittel trat ein und wirkt: Die Grenze steht in `LH-FA-05.b` *Auswahl im Replay* (v1 ist keine Sicherheitsgrenze), `TestE2EReplayAuswahl` belegt mit `pgconn` (`require_auth=scram-sha-256`), dass der Client selbst abbricht; die Sonde des Architect mit `psql` 17 und 18 bleibt deren Beleg. Ob das Replay weitere Verfahren emulieren soll, ist Nutzerfrage 1 (unten), keine Fortsetzung des Risikos. |

**Offene Fragen an den Nutzer (nicht entschieden, kein Code hängt daran, kein Register-Eintrag):** (1) Soll `replay` Klartext-Passwort, MD5 oder SCRAM emulieren, damit auch ein Client mit `require_auth` ein Verfahren verlangt? Empfehlung des Architect: nein (neuer Funktionsumfang, v1 ist keine Sicherheitsgrenze). (2) Soll `record` eine `NotificationResponse` aufzeichnen und `replay` sie wiedergeben? Empfehlung des Architect: nein in v1 (Anforderung, Formatversion und Zusage über den Zeitpunkt im Leerlauf nötig, `SPEC-039` grenzt `LISTEN`/`NOTIFY` aus). Bis zu einer Entscheidung gilt der Stand der Spezifikation: nicht zugesagt.

**Register** (Zähler = Dateien unter `evidence/`, gelesen am Stand dieser Closure; Beleg je `evidence/slice-v1-abschluss-protokollrand.md`):

| Eintrag | Zähler | Fund | Stand |
|---|---|---|---|
| `BEO-REPO/zusage-im-kommentar-weiter-als-pruefung` | 57 | F-5, V-2, V-3: „nur dieser“ in der Belegspalte, „liest beides nicht“ | verkörpert, Regel bleibt |
| `BEO-REPO/negativtests-fehlen-bei-neuem-vertrag` | 36 | F-1, V-4: Ortsangabe und Aufzählung ohne Mutation je Element | verkörpert, Regel bleibt |
| `BEO-REPO/spec-randform-erst-im-review-entschieden` | 30 | V-1: Reihenfolge `_pq_.` vor `PGR-E6003` | verkörpert, Regel bleibt |
| `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben` | 17 | V-1, vom Verifier gefunden, nicht vom Implementer zurückgegeben | verkörpert, Regel bleibt |
| `BEO-REPO/schaetzung-in-zeilen-unterschaetzt-tests` | 5 | geschätzt 800 bis 1000, gemessen 1234 | verkörpert, Regel bleibt (Auftreten trotz der Regel) |
| `BEO-REPO/spezifikation-widerspricht-sich-im-wortlaut` | 2 | F-2: Zählregel der Verbindungen | offen, unter der Schwelle |
| `BEO-REPO/gegenprobe-mutation-faerbt-zusaetzlichen-fall-zeitabhaengig` | 2 | V-8: `p7-int-treiber` einmal rot | offen, unter der Schwelle |
| `BEO-REPO/serververhalten-nur-gegen-eine-version-geprueft` | 1 | kein Auftreten (Sonde 14, 17, 18, Grenze benannt) | offen, Zähler unverändert |

Kein Eintrag erreicht mit diesem Slice neu 3× ohne Regel; `BEO-REPO/spezifikation-widerspricht-sich-im-wortlaut` und `BEO-REPO/gegenprobe-mutation-faerbt-zusaetzlichen-fall-zeitabhaengig` stehen bei 2×. Zwei Beobachtungen des Implementers (Abschnitt *Für die Closure*) sind **nicht** eingetragen, ohne Wiederkehr im Bestand und ohne passenden Eintrag: (1) `a-check` zeigt ein Tech-Leck in `test/integration` erst im vollen Gate-Lauf, nicht im engeren Sensor; (2) ein Mutantengeschirr, das auf einen festen Quelltext zielt, färbt mehr als eine Zeile, wenn der Text mehrfach vorkommt. Ob sie ein eigenes Verzeichnis bekommen, entscheidet der Nutzer (Frage 5).

**Lerneintrag — benannte Spec-Lücke, Wiederaufgetreten, Regel bleibt** (`AGENTS.md` §3.10, §3.11, §3.12, §3.14); geändert wird keine Regel, kein `liegt in`. Die Spec-Lücke ist die **Reihenfolge mehrerer Ablehnungen am Rand**: Der Code entschied `PGR-E6001` (`_pq_.`) vor `PGR-E6003`, die Spezifikation nannte sie nicht (V-1), und der Architect trug sie in `LH-FA-05.e` *Startnachricht 3.0* und `LH-FA-23.a` nach; ebenso hatte `LH-FA-05.e` für die Zählung abgelehnter Verbindungen einen anderen Wortlaut als `LH-FA-12.a` (F-2). Wiederaufgetreten sind „nur dieser“ in einer Belegspalte der Mutationstabelle (F-5, dann V-2 an der einen Zeile, die die Nacharbeit stehen ließ), Ortsangabe und Aufzählung ohne Mutation je Element (F-1, V-4) und die Schätzung, die in der Nacharbeit um den Faktor 8 statt 4 bis 5 wuchs (1234 gegen 800 bis 1000). Was funktionierte: Der Architect entschied die Randformen vor dem Code, jede Zeile bekam eine Mutation, und die Verifikation fuhr die Mutanten der Nacharbeit unabhängig nach. Vorschläge an den Nutzer, nicht als Eintrag und nicht von dieser Closure in `AGENTS.md` oder `.claude/` geändert: (3) `AGENTS.md` §3.12 oder `architect.md`: Hat ein Rand mehrere Ablehnungsgründe, ist ihre Reihenfolge eine Randform (Tabelle Gründe × Vorrang) und steht in §6 vor dem Code. (4) `.claude/commands/implement-slice.md` Schritt 19 oder `AGENTS.md` §3.14: Ein Quantor („nur dieser“) in einer Belegspalte steht nur nach Messung; die Schätzung der Tests rechnet bei einer Tabelle von Randformen mit Mutation je Element mit dem Achtfachen des Produktcodes statt dem Vier- bis Fünffachen. Frage (5) siehe Register. Retirement-Check bestanden (keine Regel entfernt oder gelockert).

**Paarungen.** (a) Anker: Der Lerneintrag trägt kein Feld `liegt in`, keine Verkörperung; nichts zu prüfen. (b) Folge-Slice: Genannt sind `slice-v1-abschluss-protokollrand-doku` und `slice-v1-abschluss-cancel-ohne-schluessel`; beide existieren in `next/` und nehmen an: `grep -n "slice-v1-abschluss-protokollrand"` findet die Kennung des Gebers im §1 und in der DoD beziehungsweise im §1 und §4 des Nehmers (der Doku-Nehmer trägt den Inhalt der Sendung seit `fdc0c93`, Nachzählung dort in §8). Diese Closure schickt keine neue Sendung. (c) Register: Alle genannten Kennungen `BEO-REPO/…` bestehen als Verzeichnis, jedes mit nicht leerem `evidence/`.

**Stand der Gates.** Die Läufe stehen oben; die Verifikation fuhr `make gates` voll grün auf `eccdbcb`, den Lauf auf dem Stand der Closure nennt der Bericht des Orchestrators, nicht dieser Absatz.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Vorgelagert — Sub-Area-Wahl prüfen:** Das Repo deklariert eine Sub-Area für das gesamte Repo (`harness/conventions.md`); der Slice berührt sie, die Schwelle ≥ 2 von 3 Achsen ist nicht berührt.

**Vorgelagert — offene Beobachtungen sichten:** Register durchgegangen; es trägt nur seine `README.md` — keine Treffer.

Nachgezählt beim Eintragen der Schichtzählung aus `slice-doku-ist-stand` (2026-10-10, Entscheidung des Nutzers, `AGENTS.md` §3.13): Der Handbuch- und README-Teil liegt im Doku-Folge-Slice `slice-v1-abschluss-protokollrand-doku` direkt hinter diesem Plan, in derselben Welle; die Dokumentation zählt hier nicht mehr mit. Liefer-Punkte: 2. Schichten: zwei Schichten (PGWire-Adapter, Upstream-Adapter).

Nachgezählt beim Start (Planner, 2026-10-15, gegen den heutigen Code und `SPEC-029` nach den Matrix- und Zusage-Slices, `AGENTS.md` §3.9, §3.13): Liefer-Punkte 2 (Tabelle `LH-FA-05.e` getestet; Replay-Handshake festgelegt und geprüft); die Randformen aus §6 gehören zu ihnen und fügen keinen hinzu. Schichten: zwei, PGWire-Adapter (`ARC-006`) und Upstream-Adapter (`ARC-007`, nur bei einer Lücke der Inventur); `test/integration` ist Test des gebauten Binaries und keine Schicht des Hexagons, die erzeugten Tabellen in `docs/user/abdeckung-*.md` zählen nicht (`slice-v1-abschluss-protokollrand-doku` §1), Meldungscode-Konstanten zählen nicht, die Festlegung in der Spezifikation durch den Architect vor dem Code nicht (§6). Berührt der Implementer Kern, Ports oder CLI, sind es drei: Rückführung nach §4. `SPEC-029` wurde durch `slice-v1-abschluss-postgres-versionen-zusage` geändert (Liste 14 bis 18, Referenz 17); der Gegenstand dieses Slice (Tabelle `LH-FA-05.e`) ist davon nicht betroffen, §1 nennt die Versionen nicht mehr als Ziel.

Nachgezählt beim Eintragen der Entscheidungen (Architect, 2026-10-15, `AGENTS.md` §3.13): Liefer-Punkte 2, unverändert; die zwei Code-Änderungen (`_pq_.`, ungültiger Rumpf) liegen im PGWire-Adapter und gehören zu Punkt 1. Schichten: zwei (PGWire-Adapter, Upstream-Adapter nur mit Tests von `toResponse` und Aufbau); die Festlegung in der Spezifikation zählt nicht (§6). Der Ausweg bei einer dritten Schicht bleibt §4.

Nachgezählt nach der Umsetzung (Implementer, 2026-10-15, `AGENTS.md` §3.13): Liefer-Punkte 2, unverändert. Schichten 2: PGWire-Adapter (Code und Tests), Upstream-Adapter (nur Tests, kein Code); Kern, Ports und CLI sind unberührt, `test/integration` und die erzeugten Tabellen zählen nicht, Meldungscode-Konstanten kamen nicht hinzu. Die Marke aus §4 ist nicht erreicht (Messung in §7).

Nachgezählt nach der Nacharbeit (Implementer, 2026-10-15, `AGENTS.md` §3.13): Liefer-Punkte 2, Schichten 2, unverändert; die Nacharbeit fügt Tests im PGWire-Adapter und im E2E hinzu, keinen Produkt-Code (der Kommentar von `startup` ist neu gesetzt). Größe 1172 nach der Metrik aus §4; die Meldeschwelle 1250 und die Marke 1400 sind nicht erreicht.

Nachgezählt nach der Nacharbeit zur Verifikation (Implementer, 2026-10-15, `AGENTS.md` §3.13): Liefer-Punkte 2, Schichten 2, unverändert; neu ist `leser_test.go` (Test im PGWire-Adapter, V-4), kein Produkt-Code. Größe 1234 nach der Metrik aus §4 (`git diff --numstat 5c4b3ae..HEAD -- internal test spec docs/user`: 1196 Einfügungen, 38 Löschungen; der Architect hat in `spec` Zeilen hinzugefügt); die Meldeschwelle 1250 ist nicht erreicht, die Marke 1400 nicht.

**Vorgelagert — Sichtung für die Berührung (Planner, 2026-10-15):** Das Register trägt inzwischen `BEO-REPO/` (die Zeile oben galt zum Datum des Plans). Treffer: `BEO-REPO/spezifikation-widerspricht-sich-im-wortlaut` (1×, offen) — die Zeilen `NotificationResponse` und `LISTEN`/`NOTIFY` (§6); `BEO-REPO/serververhalten-nur-gegen-eine-version-geprueft` (1×, offen) — die Sonde und E2E-Fälle gegen einen echten Server (§6); `BEO-REPO/spec-randform-erst-im-review-entschieden` (29×), `BEO-REPO/negativtests-fehlen-bei-neuem-vertrag` (35×), `BEO-REPO/randform-im-code-entschieden-dann-zurueckgegeben` (16×), `BEO-REPO/zusage-im-kommentar-weiter-als-pruefung` (56×), `BEO-REPO/plan-folgt-korrektur-nicht` (47×) und `BEO-REPO/slice-waechst-durch-uebernahmen` (5×) — verkörpert, die Regeln in `AGENTS.md` §3.9 bis §3.13 tragen; `BEO-REPO/verhalten-nur-unter-linux-geprueft` (3×, offen, Lücke): berührt nicht, der Slice prüft TCP-Verhalten, keine Eigenschaft des Dateisystems. Keiner der nicht verkörperten Einträge erreicht mit diesem Slice 3× neu; erreicht `BEO-REPO/spezifikation-widerspricht-sich-im-wortlaut` mit der Berichtigung der Zeile 2×, bleibt er unter der Schwelle.

**Modus-Begründungsblock:** alle berührten Sub-Areas GF (das Repo enthält noch keinen Produktionscode).
