# Slice slice-harness-ci-workflows: Gate der Workflows — Pins, Rechte und Zeitgrenzen der Dateien unter `.github/workflows/`

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.
Übernimmt ein anderer Slice den Gegenstand oder entfällt er, geht diese Datei
aus `open/` oder `next/` nach `done/` — §7 nennt in der Zeile `Gegenstand:`
Kennung oder Grund, die Liefer-Punkte der DoD bleiben leer
(§Ein Slice, dessen Gegenstand ein anderer übernimmt).

**Welle:** welle-erster-release, erste Stelle der Reihenfolge, vor `slice-harness-ci` und vor `slice-erster-release-veroeffentlichung` (Auftrag des Nutzers vom 2026-10-18: die CI gehört in welle-erster-release, vor die Veröffentlichung; Entscheidung des Nutzers vom 2026-10-18: der kritische Pfad zum ersten Release besteht nur aus diesem Slice, `slice-harness-ci`, `slice-erster-release-veroeffentlichung` und `slice-erster-release-freigabe`, die drei Nachtläufe folgen in [welle-ci-nachtlaeufe](../welle-ci-nachtlaeufe.md)). Start-Trigger weicht von der Welle ab: `slice-harness-gegenproben-aus-gates` in `done/` (die Namens- und Zuordnungsregel von `SPEC-060` Teil 1 legt die Gegenprobe dieses Slice in `GEGENPROBEN_CONTAINER`; ohne die Listen hinge sie an `GATE_CHECKS` und müsste später umziehen), dazu der Start-Trigger der Welle (§4); `slice-harness-gegenproben-aus-gates-fahrstelle-umgebung` ist keine Bedingung (Entscheidung des Nutzers vom 2026-10-18).

**Bezug:** Kein Anspruch des Produkts (`LH-*`): der Slice ändert Gates und Prüfungen des Harness, nicht das Binary. Aktive ADRs: [ADR-0026](../../adr/0026-build-und-test-im-multistage-dockerfile.md) (Docker-only, Prüfungen als Stufen und Werkzeug-Images), [ADR-0038](../../adr/0038-gate-kette-voll-und-schnell.md) (Gate-Kette, Ausnahmeliste der schnellen Kette), [ADR-0047](../../adr/0047-gegenprobe-des-container-starts-ist-ein-host-ziel.md) (Listen der Gegenproben, Host-Ziel). [ADR-0050](../../adr/0050-ci-auf-github-actions.md) (CI auf GitHub Actions, Accepted 2026-10-18) trägt Entscheidung und Gründe dieses Slice.

**Berührte Spec-Stellen:** `SPEC-063` (neu; Vertrag in `harness/vertraege/`, vor dem ersten Code-Commit geschrieben) · `SPEC-060` Teil 1 (gelesen: Namens- und Zuordnungsregel, Listen; Vertrag vom Architect am 2026-10-18 geschrieben) · [`SPEC-052`](../../../../harness/vertraege/SPEC-052-gate-kette.md) Punkte 1 bis 4 (gelesen: Aufrufarten des Treibers, Ausnahmeliste).

**Verantwortlich:** pt9912 (Zweig impl-ci-workflows)
**Autor:** Planner. **Datum:** 2026-10-18.

---

## 1. Ziel und Abgrenzung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Ein Gate `make workflows-check` (`SPEC-063`) prüft jede Workflow-Datei unter `.github/workflows/` (`*.yml` und `*.yaml`), bevor es eine gibt, auf die ein Mensch oder `make gates` sich verlassen müsste: (a) **Syntax und Ausdrücke** mit `actionlint` (Image per Digest gepinnt, netzlos, schreibgeschützt); (b) **Rechte und Zeitgrenzen** durch ein kleines eigenes Skript: `permissions: {}` auf oberster Ebene, jeder Job mit `timeout-minutes`; (c) **Bindung der Pin-Prüfung:** Die Pins (voller Commit-SHA mit Tag-Kommentar je fremde `uses:`-Referenz) prüft allein `make docs-check` über das Modul `workflows` von d-check; das Gate prüft nicht die Pins, sondern nur, dass `.d-check.yml` das Modul mit `dir: .github/workflows` führt, sobald eine Workflow-Datei existiert (`SPEC-063` Punkt 8). Der Eintrag selbst wandert in `slice-harness-ci` zusammen mit `ci.yml`: Das Modul meldet ohne Datei einen Befund (leere Prüfmenge), er kann vor der ersten Datei nicht stehen. Das Gate hängt an `GATE_CHECKS`; seine Gegenprobe `make workflows-check-gegenprobe` zeigt je Regel und je Element ihrer Aufzählungen einen Fall und eine Mutation und steht in `GEGENPROBEN_CONTAINER`, nicht in `GATE_CHECKS`.

Der Slice liefert das Gate **vor** der ersten Workflow-Datei. Er legt keine an; ohne Datei meldet er das und endet mit Exit 0 (Randform 1), und jede Datei der folgenden Slices (`slice-harness-ci`, `-ci-gegenproben`, `-ci-freshness`, `slice-erster-release-veroeffentlichung`) fällt vom ersten Commit an unter ihn.

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- Der Eintrag des Moduls `workflows` in `.d-check.yml` — kommt mit der ersten Datei, `slice-harness-ci` (Sendung, dort in §1 und DoD genannt); davor meldete `make docs-check` einen Befund über leerer Prüfmenge.
- Die Workflow-Dateien selbst (`ci.yml` und die übrigen) — `slice-harness-ci`, `slice-harness-ci-gegenproben`, `slice-harness-ci-freshness`; hier gibt es nichts, das ein Workflow ausführte, und das Gate ist ohne Datei prüfbar (Gegenprobe in Temp-Bäumen).
- Die Gültigkeit und Aktualität der SHA-Pins (existiert der Commit, bezeichnet er den Tag im Kommentar, gibt es einen neueren) — Netz, außerhalb der Gates; das Modul `workflows` von d-check nennt dieselbe Grenze. Kein Slice nimmt sie an (Frage 3); dieser Slice behauptet sie nicht (`AGENTS.md` §3.11).
- Die Lauffähigkeit auf GitHub (Runner, Rechte der Organisation, `startup_failure`) — nur dort messbar; das Gate prüft die Deklarationsklasse, nicht den Lauf.
- Branch-Schutz und „required status check“ — Einstellung auf GitHub, aus dem Klon nicht auditierbar; Grenze, die `slice-harness-ci` benennt.
- Eigene Actions unter `.github/actions/` und wiederverwendbare Workflows — das Repo hat keine; das Gate liest sie nicht (Randform 3), und ein Zusatz wäre eine Änderung des Plans, kein Zubehör.

## 2. Definition of Done

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] **Liefer-Punkt 1 (Gate):** `make workflows-check` prüft nach `SPEC-063` die drei Gruppen (Syntax und Ausdrücke, Rechte und Zeitgrenzen, Bindung der Pin-Prüfung) über jede Datei unter `.github/workflows/`, nennt je Befund Pfad, Zeile und Regel (bei Job-Eigenschaften steht der Job im Text), endet mit Exit ungleich 0 bei einem Befund, schreibt nichts in den Arbeitsbaum, braucht kein Netz zur Laufzeit und hängt an `GATE_CHECKS`; jede Entscheidung je Randform aus §6 steht vor dem ersten Code-Commit in `SPEC-063`. Fragment `harness/mk/workflows.mk`, Skript `tools/harness/workflows-check.sh`; der Eintrag in `.d-check.yml` gehört nicht dazu (`slice-harness-ci`).
- [x] **Liefer-Punkt 2 (Gegenprobe):** `make workflows-check-gegenprobe` zeigt je Punkt von `SPEC-063` und je Element seiner Aufzählungen (Dateiendung, Form von `permissions`, Job-Art, Bindung der Pin-Prüfung) einen Fall, der abgelehnt, und einen, der angenommen wird, dazu je Zusage eine Mutation des Skripts, die nur den Fall ihrer Gruppe färbt (`AGENTS.md` §3.10); die unveränderte Kopie grün; Aufrufarten `-n`, `-q`, `-t`, `-i` und `MAKEFLAGS` aus der Umgebung je ein Fall (`AGENTS.md` §3.12). Das Ziel steht in `GEGENPROBEN_CONTAINER` (Namens- und Zuordnungsregel von `SPEC-060`).
- [x] **Liefer-Punkt 3 (Gate-Index):** `harness/README.md` §Sensors führt die Zeilen von Gate und Gegenprobe mit Vertrag und Bindung; die Prosa über das Gate nennt die Regel an den Schreiber einer Workflow-Datei und zeigt auf `SPEC-063` und `.d-check.yml` als Quelle, nicht auf eine nachgeschriebene Aufzählung (`AGENTS.md` §3.11).
- [x] `make gates` grün (Stop-Hook verlangt den vollen Lauf, weil `harness/` und `tools/` ändern) und `make gates-schnell-gegenprobe` grün (die Deckung zählt die neue Gegenprobe); `make workflows-check-gegenprobe` grün auf dem Endstand. `make gates` am Integrationsstand `dffe1ccf` im Host-Worktree: Exit 0, am 2026-10-18 (V-1); `make gates-schnell-gegenprobe` und `make workflows-check-gegenprobe` sind am Endstand grün (§7).
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben oder „keine Beobachtung angefallen“ in §7 notiert.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen).
- [x] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen.

## 3. Plan (vor Code)

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `harness/mk/workflows.mk`, `tools/harness/workflows-check.sh` | neu | Gate: `actionlint` im gepinnten Image, eigene Regeln für `permissions` und `timeout-minutes`, Bindung der Pin-Prüfung in `.d-check.yml` (lesend); hängt an `GATE_CHECKS` |
| `tools/harness/workflows-check-gegenprobe.sh` (Ziel im Fragment `harness/mk/workflows.mk`) | neu | Gegenprobe in Temp-Bäumen und Kopien, ohne Abdeckungs-Deklaration (`SPEC-063` Punkt 12); Eintrag in `GEGENPROBEN_CONTAINER` |
| `harness/vertraege/SPEC-063-…md` | neu (Architect) | Vertrag des Gates; vor dem Code |
| `harness/README.md` §Sensors | update | zwei Zeilen und die Prosa nach §3.11 |

## 4. Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): `slice-harness-gegenproben-aus-gates` liegt in `done/` (Listen und Namensregel), dazu der Start-Trigger von [welle-erster-release](welle-erster-release.md) (§2 dort), und der Architect hat `SPEC-063` und die ADR geschrieben, jede Randform aus §6 entschieden (`AGENTS.md` §3.12).

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next`: das Gate verlangt mehr als drei Liefer-Punkte, oder der Diff ist nicht in einer Review-Sitzung prüfbar — zurück zur Zerlegung. Marke (Metrik nach `AGENTS.md` §3.14): die Summe aus Einfügungen und Löschungen von `git diff --numstat <Basis>..<letzter Commit des Slice> -- .github tools harness Makefile`, Tests und Gegenprobe eingeschlossen, liegt über 900; Basis: Elternteil des Commits, der diese Datei nach `in-progress/` bewegt, `a98d0b9e`. Schätzung des Planners in dieser Metrik (2026-10-18, ohne Basis): Fragment und Skript des Gates 90 bis 130, Gegenprobe das Doppelte bis Dreifache des Skripts (220 bis 340), `SPEC-063` 120 bis 180, `harness/README.md` und `.d-check.yml` 25 bis 40, zusammen 455 bis 690 (die Zeile `.d-check.yml` entfällt mit Randform 12; maßgeblich ist die Schätzung des Architect in §8). Schnitt, falls die Marke eintritt: *Syntax* (Gruppe a) und *Rechte, Zeitgrenzen, Bindung* (Gruppen b und c).
- `in-progress` → `open`: `slice-harness-gegenproben-aus-gates` liegt nicht in `done/` — extern klären.

## 5. Closure-Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

DoD vollständig, `make gates` und `make workflows-check-gegenprobe` grün auf dem Endstand, Review- und Verifikations-Report liegen vor, Closure-Notiz mit Lerneintrag geschrieben.

## 6. Risiken und offene Punkte

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- **Das Gate prüft eine Klasse, nicht die Lauffähigkeit** (die Grenze des Moduls `workflows` und von `actionlint`): ein grünes Gate sagt nichts über den Lauf auf GitHub. — **Ausgang (vorgesehen):** weiter offen → neues `BEO-REPO/workflow-gate-gruen-lauf-rot` bei der Closure, wenn `slice-harness-ci` einen Lauf trifft, den das Gate hätte fangen sollen; sonst entfallen mit dem Hinweis in `SPEC-063`.
- **Der Pin-Check hängt am gepinnten d-check** (Version des Moduls, Verhalten bei `.yaml`, Grenze der Zerlegung der Blockform); er läuft in `make docs-check`, nicht in diesem Gate, und die Bindung prüft dieses Gate nach `SPEC-063` Punkt 8. — **Ausgang (vorgesehen):** weiter offen → an `slice-harness-ci`, der den Eintrag setzt und die Pins mit der ersten Datei zum ersten Mal wirklich prüft (`SPEC-064` Punkt 12 zeigt es an echtem d-check); sonst entfallen mit Grund bei der Closure.
- **`actionlint` ruft `shellcheck` auf `run:`-Blöcke auf**; Befunde dort sind Stil, nicht Fehler, und könnten das Gate dauerhaft rot machen. — **Ausgang (vorgesehen):** entfallen, wenn `SPEC-063` die Einstufung festlegt (Randform 5) und die Gegenprobe sie zeigt.
- **Die Gegenprobe braucht das Image von `actionlint`** (Netz beim ersten Pull, wie jedes gepinnte Werkzeug-Image). — **Ausgang (vorgesehen):** entfallen, weil die Gegenprobe in `GEGENPROBEN_CONTAINER` steht und kein Teil von `make gates` ist; der Lauf des Gates selbst ist netzlos nach dem Pull.

**Randformen** (`AGENTS.md` §3.12) — alle vom Architect entschieden vor dem ersten Code-Commit in `SPEC-063` (Technik-Stratum, `harness/vertraege/`), mit ADR für Entscheidung und Gründe. Vorbereitet vom Planner am 2026-10-18 (Empfehlungen, kein Beschluss):

1. **Kein Verzeichnis, leeres Verzeichnis, keine Datei.** Empfehlung: Exit 0 mit einer Zeile „keine Workflows“, nicht still; ein Fall je Form. Gate-Wahrheit „grün über leerem Prüfbereich“ benennt `SPEC-063` als Grenze (`LH-QA-01`-Muster wie `history-range-guard`). **Entschieden:** `SPEC-063` Punkt 2 (Exit 0 mit Meldung, ohne Docker; ein Verzeichnis nur mit Symlinks ist Befund `symlink`, Exit 1, Fall `p2-nur-symlink`; Grenze in Punkt 11).
2. **Dateiendungen und Ort.** GitHub liest `*.yml` und `*.yaml` unmittelbar unter `.github/workflows/`, keine Unterverzeichnisse. Empfehlung: beide Endungen, Unterverzeichnisse und andere Endungen nicht geprüft, aber mit Hinweis genannt; ein Fall je Endung und je Tiefe. **Entschieden:** `SPEC-063` Punkt 1 (beide Endungen, kein Unterverzeichnis, Hinweis).
3. **Weitere Orte.** `.github/actions/*/action.yml` (zusammengesetzte Actions), `.github/dependabot.yml`: nicht geprüft; nennt der Vertrag als Grenze, weil das Repo keine führt. **Entschieden:** `SPEC-063` Punkt 11 (nicht gelesen, Grenze).
4. **Formen von `permissions`.** Oberste Ebene: fehlt; `permissions: {}`; leerer Block; `read-all`/`write-all`; Block mit Eintrag; Anker/Alias. Empfehlung: nur `{}` besteht; alles andere ist ein Befund mit der Form im Text. Jobebene: gelockert wird nur mit benannten Scopes (kein `write-all`); ein Fall je Form. **Entschieden:** `SPEC-063` Punkt 6 (oben nur `{}`, am Job `{}` oder Block mit `read`, `write`, `none`).
5. **Einstufung der Befunde.** Wann ist ein Befund von `actionlint` (inklusive `shellcheck`) ein Fehler: alle, oder eine Teilmenge (`-ignore` ist ein Weg an der Suppression-Regel vorbei, `AGENTS.md` §3.2 gilt dem Go-Code, das Muster `# Why:` ist der Maßstab). Empfehlung: alle sind Befund; eine Ausnahme nur in einer Konfiguration mit Begründung. **Entschieden:** `SPEC-063` Punkt 4 (jede Zeile ist ein Befund; keine Option, keine Konfigurationsdatei von `actionlint`).
6. **`timeout-minutes`.** Pflicht je Job mit `runs-on`; Obergrenze (Empfehlung: kleiner als der GitHub-Standard 360; die Zahl legt der Vertrag fest); ein Wert als Ausdruck (`${{ … }}`) oder 0; ein Job, der einen wiederverwendbaren Workflow aufruft (`uses:` auf Jobebene), darf `timeout-minutes` nicht tragen (GitHub lehnt es ab): zwei Fälle. **Entschieden:** `SPEC-063` Punkt 7 (1 bis 60 bei `runs-on:`, Normalform ohne führende Null, Vorzeichen und Dezimalstelle; Aufruf-Job ausgenommen).
7. **Reihenfolge der Gründe.** Eine Datei kann mehrfach abgelehnt werden (kaputtes YAML, unpinned `uses:`, fehlende `permissions`). Empfehlung: Syntax zuerst; danach laufen die übrigen Gruppen alle, damit ein Lauf alle Befunde nennt; die Ausgabe ist je Datei sortiert. Ein Fall je Paar. **Entschieden:** `SPEC-063` Punkt 9 (Umgebung vor Befunden, sonst alle Gruppen in einem Lauf, feste Folge).
8. **Aufrufarten des Treibers** (`AGENTS.md` §3.12): `-n`, `-q`, `-t`, `-i`, `MAKEFLAGS` aus der Umgebung, einzeln und kombiniert; das Gate liefert ein Ergebnis, das der Stop-Hook über den Nachweis glaubt. Empfehlung: das Rezept enthält nur einen Docker-Aufruf und kein `$(MAKE)`, `-n`/`-q`/`-t` führen es nicht aus; `-i` schlägt durch (kein verschluckter Befund); je Flag ein Fall. **Entschieden:** `SPEC-063` Punkt 10 (Fälle `-n`, `-q`, `-t`, `-i`, `MAKEFLAGS`; der Nachweis der Kette liegt bei `SPEC-052` Punkt 21).
9. **Aufruf aus einem Unterverzeichnis; Quelle read-only.** Das Gate urteilt über das Repo seines Arbeitsverzeichnisses; der Mount ist schreibgeschützt; Symlinks unter `.github/workflows/` (Ziel außerhalb): nicht gefolgt, als Befund genannt. Ein Fall je Form. **Entschieden:** `SPEC-063` Punkte 1, 3 und 10 (Symlink mit Endung ist Befund, Symlink mit anderer Endung Hinweis, Mount `:ro`, Wurzel aus dem Skriptpfad).
10. **Gleichzeitige Läufe und Parallelität** (`make -j`): `GATE_CHECKS` läuft parallel; Container-Namen sind eindeutig oder ohne Namen (`--rm`, `docker run` ohne `--name`); Aufruf-Voraussetzung nach `SPEC-052` Punkt 8 benennen. **Entschieden:** `SPEC-063` Punkte 3 und 10 (kein `--name`, kein Hilfsverzeichnis mit festem Namen).
11. **Version und Digest von `actionlint`** und Herkunft des Images (gepinnt per Digest, `docker.io` oder `ghcr.io`); wo der Pin steht (`harness/mk/workflows.mk`); Verhalten bei fehlendem Image (Pull-Fehler: Exit ungleich 0, nicht „keine Befunde“). **Entschieden:** `SPEC-063` Punkt 3 (`rhysd/actionlint@sha256:<Index-Digest>` vom Docker Hub (ghcr.io ist anonym nicht ziehbar); Pull-Fehler Exit 2; Exit 3 mit Rechtehinweis; Tag und Digest ermittelt der Implementer).
12. **Zusammenspiel mit `make docs-check`.** Geben beide denselben Pin-Befund, ist es ein Befund in zwei Gates; Empfehlung: die Pins prüft allein `docs-check` (Modul), `workflows-check` prüft sie nicht ein zweites Mal; `SPEC-063` nennt es, die Gegenprobe zeigt es mit einer `docs-check`-Kopie. **Entschieden:** `SPEC-063` Punkt 8. **Abweichung vom ursprünglichen Plan (in §1, §2 und §3 nachgezogen):** das Modul `workflows` meldet ohne Datei und ohne `uses:` einen Befund (leere Prüfmenge); der Eintrag in `.d-check.yml` kann deshalb nicht vor der ersten Workflow-Datei stehen. Das Gate prüft nur, dass er steht, sobald eine Datei existiert; der Eintrag kommt mit `ci.yml` im Slice `slice-harness-ci`.

**Fragen an den Nutzer** (jede mit Empfehlung des Planners; eine Empfehlung ist keine Entscheidung):

1. **Schnitt und Reihenfolge.** Beauftragt waren zwei Slices (`slice-harness-ci`, `slice-harness-ci-freshness`) mit je Marke 900; die Schätzung ungeteilt liegt bei rund 1050 bis 1650 (CI) und 900 bis 1400 (Freshness). Nach der Regel „schneiden, wenn die Schätzung die Marke überschreitet“ sind es fünf: `slice-harness-ci-workflows` (dieser), `slice-harness-ci`, `slice-harness-ci-gegenproben`, `slice-harness-ci-freshness`, `slice-harness-ci-freshness-images`. Empfehlung: so, in dieser Reihenfolge. Alternative: dieser Slice zusammen mit `slice-harness-ci` (Schätzung 1000 bis 1400, darüber).
2. **Pins durch das Modul `workflows` von d-check oder durch eigenes Skript.** **Entschieden:** Modul, mit [ADR-0050](../../adr/0050-ci-auf-github-actions.md) (Accepted 2026-10-18) und `SPEC-063` Punkt 8; kein zweiter Parser.
3. **Aktualität und Gültigkeit der Action-SHA** (Netz). Empfehlung: als dritte Achse in `slice-harness-ci-freshness-images` oder als eigener Slice danach; heute nimmt keiner an.

## 7. Closure-Notiz

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<KUERZEL>/<slug>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks). Ging der Gegenstand an einen anderen Slice oder entfiel er, trägt
diese Sektion die Zeile `Gegenstand:` mit Kennung oder Grund und jedes Risiko
aus §6 seinen Ausgang; die Liefer-Punkte der DoD bleiben leer
(`modul-05-planning-harness.md` §Ein Slice, dessen Gegenstand ein anderer
übernimmt).

### Belege des Implementers

Stand: Zweig `impl-ci-workflows`, letzter Code-Commit `bdfbedf5` (Gate `7a66cc39`, Gegenprobe `a207e17c`, Gate-Index `0c30b767`, Symlink-Fall `c92ed918`, Review-Nacharbeit `1bdaaefe` und `6f4058fe`, Werkzeugliste im Kopf des Fragments `bdfbedf5`), im Dev-Container pgr-dev3 (Docker-in-Docker, bash 5, mawk). Basis der Größenmetrik: `a98d0b9e`.

**Randform-Rückgabe vor dem Code** (Image-Herkunft und Rechte des Nicht-root-Images): vom Architect in `SPEC-063` Punkte 3 und 12 entschieden (Commit `2890e31f`); das Fragment trägt `rhysd/actionlint@sha256:887a259a…147e9` (Index-Digest von Tag 1.7.7, Docker Hub).

**Läufe am Endstand (alle im Container; nach V-4 lief die Gegenprobe einmal, grün, 100 Läufe):**

| Lauf | Ergebnis |
|---|---|
| `make workflows-check-gegenprobe` | grün, 100 Läufe (unveränderte Kopie und 99 Mutationen), 98 Fälle, davon 3 echte gegen die Images von `actionlint` und d-check; als root (`sudo -n`, ebenfalls im Container) grün mit 97 Läufen, die drei Fälle mit Rechten und ihre drei Mutationen entfallen und stehen am Ende auf stderr |
| `make gates-schnell-gegenprobe` | grün (Ausnahmeliste deckt `GATE_CHECKS`, Namensregel von `SPEC-060` Punkt 2 am Arbeitsbaum mit der neuen Gegenprobe) |
| `make gates` | am Stand `6f4058fe` bis auf `docs-check` grün (`make -k gates`); `docs-check` meldete drei Befunde `id-unlinked` im Review-Report, behoben im Commit `e9219f59` des Reviewers (Links). Der volle Lauf am Endstand lief im Host-Worktree am Integrationsstand `dffe1ccf`: Exit 0 (Verifikation V-1) |
| `make docs-check` | 0 Befunde am Stand `bdfbedf5` (nach `e9219f59`) |
| `make gates-schnell-gegenprobe` | grün am Endstand |
| echter Lauf des Gates | an einer Datei mit Ausdrucksfehler, `permissions: read-all`, `timeout-minutes: 99`, einem Job ohne Zeitgrenze und `contents: admin`: 10 Befunde (4 von `actionlint`, 5 eigene, 1 Bindung), Exit 1 |
| d-check (`real-pins`) | `uses: actions/checkout@v4` ⇒ `uses-pin-missing`, voller SHA ohne Kommentar ⇒ `uses-pin-untagged`, mit Tag-Kommentar ⇒ 0 Befunde (Image `DCHECK_REF`, v0.86.1) |

**Zusage · Mutation · roter Test.** Jede Mutation ist ein Textersatz in einer Kopie von Skript oder Fragment (`mut` in `tools/harness/workflows-check-gegenprobe.sh`, Name `m-…` ist der Schlüssel; `GP_MUT=<Name>` fährt sie einzeln, `GP_ENTDECKE=1` nennt die roten Fälle). Rot sind genau die Fälle der letzten Spalte; die Mutation ist von der Gegenprobe selbst erwartet, ein Unterschied zwischen erwarteter und gefundener Menge macht die Gegenprobe rot. „breit“ heißt: die Mutation färbt jeden Fall, der die Zusage nebenbei braucht; die Gegenprobe prüft dort, dass der benannte Kern rot ist und die ausdrücklich genannten Fälle grün bleiben. Fälle anderer Punkte stehen in der Spalte, wo sie die Regel als Auslöser eines Befunds benutzen (zum Beispiel `p1-yml` benutzt `permissions-fehlt`, wie der Vertrag es in Punkt 1 vorgibt).

| Zusage | Mutation | Name | rote Fälle |
|---|---|---|---|
| P1 Endung `.yml` wird geprüft | Prüfbereich nur `.yaml` (breit: jeder Fall mit `.yml`-Datei) | `m-p1-nur-yaml` | `p1-symlink` `p1-symlink-andere-endung` `p1-unterverzeichnis` `p1-yml` `p10-i` `p10-rezept` … (70 Fälle) |
| P1 Endung `.yaml` wird geprüft | Prüfbereich nur `.yml` | `m-p1-nur-yml` | `p1-yaml` `p3-e6` `p9-gruen` |
| P1/P3/P9 Reihenfolge der Namen | `sort -rz` statt `sort -z` | `m-p1-reihenfolge` | `p3-e6` `p9-reihenfolge` |
| P1 kein Unterverzeichnis | rekursive Suche | `m-p1-rekursiv` | `p1-unterverzeichnis` |
| P1 Symlink ist Befund, nicht gefolgt | Symlink wie reguläre Datei | `m-p1-symlink-gefolgt` | `p1-symlink` `p2-nur-symlink` |
| P1 Endung ist das Ende des Namens | Endung als Teilstring (`*.yml*`) | `m-p1-teilstring` | `p1-andere-endung` |
| P2 F1 kein Verzeichnis: Exit 0 mit Meldung | F1 endet mit Exit 2 | `m-p2-f1-exit2` | `p2-kein-verzeichnis` |
| P2 F2 leeres Verzeichnis: Meldung | F2 endet still | `m-p2-f2-still` | `p2-leer` `p2-ohne-4` |
| P2 F3 nur andere Dateien: kein `docker` | F3 geht weiter und ruft `docker` | `m-p2-f3-docker` | `p1-andere-endung` `p2-nur-andere` `p2-nur-symlink` `p2-ohne-8` |
| P2 ohne die Prüfung von Punkt 4 | Punkt 4 läuft vor der Meldung | `m-p2-punkt4` | `p2-ohne-4` |
| P2 F4 nur Symlinks: Befund `symlink`, Exit 1, keine Meldung von F3 | Verzeichnis nur mit Symlinks endet mit Exit 0 und der Meldung von F3 | `m-p2-f4-wie-f3` | `p2-nur-symlink` |
| P2 F4 ohne Aufruf von `docker` | Skript ruft bei F4 `docker` | `m-p2-f4-docker` | `p2-nur-symlink` |
| P2 ohne die Prüfung von Punkt 8 | Punkt 8 läuft vor der Meldung | `m-p2-punkt8` | `p1-andere-endung` `p2-kein-verzeichnis` `p2-leer` `p2-nur-andere` `p2-ohne-4` `p2-ohne-8` |
| P3 Digest hat 64 Hexziffern | 63 Hexziffern | `m-p3-digest-kurz` | `p3-digest-form` |
| P3 Repository `rhysd/actionlint` | `ghcr.io/rhysd/actionlint` | `m-p3-digest-repository` | `p3-digest-form` |
| P3 Digest-Form `@sha256:` | Tag statt Digest | `m-p3-digest-tag` | `p3-digest-form` |
| P3 fehlendes `docker` ist Exit 2 | Exit 127 gilt als keine Befunde | `m-p3-docker-fehlt-als-0` | `p3-kein-docker` `p9-umgebung-vor-befund` |
| P3 E1 `--rm` | `--rm` fehlt | `m-p3-e1` | `p3-e1` |
| P3 E2 `--network none` | `--network none` fehlt | `m-p3-e2` | `p3-e2` |
| P3 E3 Mount `:ro` | `:ro` fehlt | `m-p3-e3` | `p3-e3` |
| P3 E4 Image aus `WORKFLOWS_ACTIONLINT` | festes Image statt der Variable | `m-p3-e4` | `p3-e4` |
| P3 E5 `-oneline` | `-oneline` fehlt | `m-p3-e5` | `p3-e5` |
| P3 E6 Dateiliste vollständig | nur die erste Datei | `m-p3-e6` | `p3-e6` |
| P3 E7 kein `--name` | `--name` kommt hinzu | `m-p3-e7` | `p3-e7` |
| P3 E8 kein `-ignore` | `-ignore` kommt hinzu | `m-p3-e8-ignore` | `p3-e8` |
| P3 E8 kein `-pyflakes` | `-pyflakes=` kommt hinzu | `m-p3-e8-pyflakes` | `p3-e8` |
| P3 E8 kein `-shellcheck` | `-shellcheck=` kommt hinzu | `m-p3-e8-shellcheck` | `p3-e8` |
| P3 Exit 1 heißt Befunde | Exit 1 gilt als 0 | `m-p3-exit1-als-0` | `p10-i` `p10-unterverzeichnis` `p3-exit1` `p3-exit1-leer` `p9-reihenfolge` `real-ausdruck` |
| P3 Exit 1 ohne Zeile ist Befund | Zweig entfällt (Exit 1 ohne Zeile gilt als grün) | `m-p3-exit1-leer-angenommen` | `p3-exit1-leer` |
| P3 Hinweis nur bei Exit 3 | Hinweis bei jedem Exit mit `permission denied` | `m-p3-hinweis-bei-jedem-exit` | `p3-exit2` |
| P3 Hinweis nur mit `permission denied` | Hinweis bei jedem Exit 3 | `m-p3-hinweis-bei-jedem-exit3` | `p3-exit3` |
| P3 Hinweis bei Exit 3 mit `permission denied` | Hinweis entfällt | `m-p3-hinweis-fehlt` | `p3-exit3-rechte` |
| P3 leeres Image: Exit 2 | leeres Image wird gerufen | `m-p3-image-leer` | `p3-image-leer` |
| P3 anderer Exit heißt Exit 2 | Exit 2, 3, 125, 127 gelten als 1 | `m-p3-jeder-exit-als-1` | `p3-exit125` `p3-exit2` `p3-exit3` `p3-exit3-rechte` `p3-kein-docker` `p9-umgebung-vor-befund` |
| P3 genau ein Aufruf | zweiter Aufruf von `docker` | `m-p3-zweimal` | `p10-i` `p10-rezept` `p3-einmal` |
| P4 `actionlint.yaml` ist Befund | Endung `.yaml` nicht geprüft | `m-p4-yaml-nicht` | `p4-yaml` |
| P4 `actionlint.yml` ist Befund | Endung `.yml` nicht geprüft | `m-p4-yml-nicht` | `p4-yml` |
| P5 E2 erster Job-Schlüssel mit Einzug 2 | Einzug nicht geprüft | `m-p5-einzug` | `p5-einzug` |
| P5 E2 späterer Job-Schlüssel mit Einzug 1 oder 3 | Einzug 1/3 nicht geprüft | `m-p5-einzug-spaeter` | `p5-einzug-spaeter` |
| P5 Schritt-Eigenschaft ist keine Job-Eigenschaft | Suche auf jedem Einzug ab 4 | `m-p5-jeder-einzug` | `p5-schritt-ist-kein-job` `p6-job-wert` |
| P5 E3 `jobs:` allein in der Zeile | Wert hinter `jobs:` angenommen | `m-p5-jobs-flow` | `p5-jobs-flow` |
| P5 E1 Tabulator im Einzug | Tabulator still angenommen | `m-p5-tab` | `p5-form-ohne-regeln` `p5-tab` |
| P6 oben fehlt `permissions`: Befund | fehlendes `permissions` angenommen | `m-p6-fehlt-angenommen` | `p1-yaml` `p1-yml` `p6-fehlt` `p9-alle-befunde` `p9-reihenfolge` |
| P6 Flow-Mapping mit Einträgen am Job ist Befund | Flow-Mapping am Job angenommen | `m-p6-flow-am-job` | `p6-job-flow-eintrag` |
| P6 oben nur `{}` | jeder Wert oben angenommen | `m-p6-jeder-wert-oben` | `p6-block` `p6-flow-eintrag` `p6-read-all` `p6-write-all` |
| P6 `permissions` am Job nicht verlangt | `permissions` am Job verlangt (breit) | `m-p6-job-pflicht` | `p1-symlink` `p1-symlink-andere-endung` `p1-unterverzeichnis` `p1-yaml` `p1-yml` `p10-rezept` … (55 Fälle) |
| P6 Skalar am Job ist Befund | Skalar am Job angenommen | `m-p6-skalar-am-job` | `p6-job-read-all` `p6-job-write-all` `p9-alle-befunde` |
| P6 Wert im Block nur read, write, none | unbekannter Wert angenommen | `m-p6-unbekannter-wert` | `p6-job-wert` |
| P7 Ausdruck ist Befund | Ausdruck angenommen | `m-p7-ausdruck-angenommen` | `p7-ausdruck` |
| P7 Job ohne `runs-on` ausgenommen | Job ohne `runs-on` geprüft | `m-p7-job-ohne-runs-on` | `p7-uses-job-ok` |
| P7 `30.5` ist Befund | Nicht-Ganzzahl angenommen | `m-p7-nicht-ganzzahl-angenommen` | `p7-dezimal` `p7-nicht-ganzzahl` |
| P7 0 ist Befund | 0 angenommen | `m-p7-null-angenommen` | `p7-0` |
| P7 Obergrenze unter 360 | Obergrenze 360 | `m-p7-obergrenze-360` | `p7-61` |
| P7 Obergrenze 60 | Obergrenze 61 | `m-p7-obergrenze-61` | `p7-61` |
| P7 Zeitgrenze Pflicht | Pflicht entfällt | `m-p7-pflicht-entfaellt` | `p5-schritt-ist-kein-job` `p7-fehlt` `p9-alle-befunde` `p9-reihenfolge` |
| P7 Untergrenze 1 | Untergrenze 2 | `m-p7-untergrenze` | `p7-1-ok` |
| P7 Wort ist Befund | Wort angenommen | `m-p7-wort-angenommen` | `p7-wort` |
| P8 (a) `modules:` führt `workflows` | (a) nicht geprüft | `m-p8-a` | `p8-modules` `p8-modules-praefix` `p8-modules-suffix` |
| P8 `"…"` zulässig | doppelte Anführungszeichen nicht zugelassen | `m-p8-anfuehrung-doppelt` | `p8-ok-doppelt` |
| P8 `'…'` zulässig | einfache Anführungszeichen nicht zugelassen | `m-p8-anfuehrung-einfach` | `p8-ok-einfach` |
| P8 (b) Zeile `workflows:` | (b) nicht geprüft | `m-p8-b` | `p8-block` |
| P8 (c) `dir: .github/workflows` | (c) nicht geprüft | `m-p8-c` | `p8-dir` `p8-dir-danach` `p8-dir-davor` `p8-dir-schraeg` |
| P8 fehlende `.d-check.yml` ist Befund | fehlende Datei angenommen | `m-p8-datei-fehlt-angenommen` | `p8-ohne-datei` `p9-reihenfolge` |
| P8 das Gate meldet Pins nicht selbst | Skript meldet unpinnte Referenz | `m-p8-pins-selbst` | `p8-pins-nicht-hier` |
| P8 ohne schließenden Schrägstrich | Schrägstrich am Ende zugelassen | `m-p8-schraegstrich` | `p8-dir-schraeg` |
| P9 `actionlint` zuerst | Datei-Befunde vor `actionlint` | `m-p9-datei-vor-al` | `p9-reihenfolge` |
| P9 Umgebungsfehler vor Befunden | Gruppen (b), (c) laufen vor dem Umgebungsfehler | `m-p9-eigene-vor-umgebung` | `p9-umgebung-vor-befund` |
| P9 alle Befunde in einem Lauf | Ausgabe endet beim ersten Befund | `m-p9-erster-befund` | `p3-exit1` `p9-alle-befunde` `p9-reihenfolge` |
| P9 Befunde ohne Datei zuletzt | Befunde ohne Datei vor den Datei-Befunden | `m-p9-global-vor-datei` | `p9-reihenfolge` |
| P9 nicht lesbare Datei: Exit 2 | Datei still übergangen | `m-p9-nicht-lesbar` | `p9-nicht-lesbar` |
| P9 Befunde nach Zeile | Sortierung entfällt | `m-p9-ohne-sortierung` | `p9-alle-befunde` |
| P9 Summe beider Quellen | Summe zählt nur `actionlint` (breit) | `m-p9-summe-nur-al` | `p1-symlink` `p1-yaml` `p1-yml` `p2-nur-symlink` `p4-yaml` `p4-yml` … (41 Fälle) |
| P9 Summe beider Quellen | Summe ohne `actionlint` | `m-p9-summe-ohne-al` | `p10-unterverzeichnis` `p3-exit1` `p3-exit1-leer` `p9-reihenfolge` |
| P9 Umgebungsfehler ist Exit 2 | Exit 1 | `m-p9-umgebung-exit1` | `p3-exit125` `p3-exit2` `p3-exit3` `p3-exit3-rechte` `p3-kein-docker` `p9-umgebung-vor-befund` |
| Gate hängt an `GATE_CHECKS` | Zeile entfällt | `m-p10-kette-gate` | `p10-kette-gate` |
| Gegenprobe steht in `GEGENPROBEN_CONTAINER` | Zeile entfällt | `m-p10-kette-gegenprobe` | `p10-kette-gegenprobe` |
| P10 Rezept ohne `+` (`-n`, `-q`, `-t`, `MAKEFLAGS`) | `+` vor dem Rezept | `m-p10-plus` | `p10-makeflags` `p10-n` `p10-q` `p10-t` |
| P10 schreibt nichts in den Baum | Skript legt eine Datei im Baum an | `m-p10-schreibt` | `p10-schreibt-nichts` |
| P10 Wurzel aus Skriptpfad | Wurzel ist das Arbeitsverzeichnis | `m-p10-wurzel-ist-arbeitsverzeichnis` | `p10-unterverzeichnis` |
| P10 Rezept ruft das Skript genau einmal | Rezept doppelt | `m-p10-zweimal` | `p10-i` `p10-rezept` |
| P12 echtes Image findet den Ausdrucksfehler | Image durch Attrappe mit Exit 0 ersetzt (Umgebung) | `m-real-attrappe-image` | `real-ausdruck` |
| P12 d-check meldet Pins mit `workflows` in `modules:` | `modules:` ohne `workflows` (Umgebung) | `m-real-modules` | `real-pins` |
| P1 Symlink mit anderer Endung ist Hinweis `(Endung)`, kein Befund | wird Befund | `m-p1-symlink-andere-befund` | `p1-symlink-andere-endung` |
| P1 Hinweis für Symlink mit anderer Endung | Hinweis entfällt | `m-p1-symlink-andere-still` | `p1-symlink-andere-endung` |
| P1 Hinweis für Datei mit anderer Endung | Hinweis entfällt | `m-p1-hinweis-endung-fehlt` | `p1-andere-endung` |
| P1 Grund `(Endung)` im Hinweis | Grund `(Name)` | `m-p1-hinweis-grund-endung` | `p1-andere-endung` |
| P1 Hinweis für Datei im Unterverzeichnis | Hinweis entfällt | `m-p1-hinweis-unterverz-fehlt` | `p1-unterverzeichnis` |
| P1 Grund `(Unterverzeichnis)` im Hinweis | Grund `(Ordner)` | `m-p1-hinweis-grund-unterverz` | `p1-unterverzeichnis` |
| P3 Zeilen von `actionlint` unverändert in der Ausgabe | Zeile bekommt ein Präfix | `m-p3-al-zeilen-veraendert` | `p3-exit1` |
| P3 stderr des Aufrufs hängt an der Meldung | Anhang entfällt | `m-p3-stderr-anhang-fehlt` | `p3-exit125` `p3-exit2` `p3-exit3` |
| P5 bei `form` laufen die Regeln 6 und 7 nicht | `exit` nach den Form-Befunden entfällt | `m-p5-regeln-laufen` | `p5-form-ohne-regeln` |
| P7 Normalform ohne führende Null | führende Null angenommen | `m-p7-fuehrende-null-angenommen` | `p7-fuehrende-null` |
| P7 Normalform ohne Vorzeichen | Vorzeichen angenommen | `m-p7-vorzeichen-angenommen` | `p7-vorzeichen` |
| P7 `5.0` ist Befund | Dezimalform angenommen | `m-p7-dezimal-angenommen` | `p7-dezimal` |
| P8 (c) `dir:` unter `workflows:` (nicht davor, nicht in anderem Block) | `dir:` zählt ohne Block | `m-p8-dir-ohne-block` | `p8-dir-danach` `p8-dir-davor` |
| P8 (c) `dir:` vor dem nächsten Schlüssel in Spalte 1 | Rücksetzung bei Schlüssel in Spalte 1 entfällt | `m-p8-ohne-ruecksetzung` | `p8-dir-danach` |
| P8 (a) das Element ist genau `workflows` | Element als Muster `~ /workflows/` | `m-p8-modules-muster` | `p8-modules-praefix` `p8-modules-suffix` |
| P9 Verzeichnis ohne Leserecht: Exit 2 | Prüfung `-r` entfällt | `m-p9-verzeichnis-r-fehlt` | `p9-verzeichnis-ohne-r` |
| P9 Verzeichnis ohne Durchsuchrecht: Exit 2 | Prüfung `-x` entfällt | `m-p9-verzeichnis-x-fehlt` | `p9-verzeichnis-ohne-x` |

**Grüne Mutanten:** keiner. Alle 99 Mutationen färben mindestens einen Fall; es gibt deshalb keinen Mutanten, der als äquivalent einzuordnen wäre.

**Befundzeilen vorher und nachher:** kein Bestand (das Gate liegt vor der ersten Workflow-Datei; `.github/workflows/` fehlt im Arbeitsbaum).

**Metrik gegen die Marke von §4** (Summe aus Einfügungen und Löschungen von `git diff --numstat a98d0b9e..bdfbedf5 -- .github tools harness Makefile`): 899 (878 Einfügungen, 21 Löschungen), davon 44 aus den Vertragsdateien des Architect (`harness/vertraege`); ohne sie 855 (`workflows-check-gegenprobe.sh` 589, `workflows-check.sh` 240, `workflows.mk` 24, `harness/README.md` 2). Meldeschwelle 700 überschritten, Marke 900 nicht (um eine Zeile unterschritten); jede weitere Zeile in diesen Pfaden überschreitet sie.

**Rückgabe an den Architect, erledigt:** Prüfbereich nur aus Symlinks (`SPEC-063` Punkt 2, F4): Der Architect hat entschieden (Befund `symlink`, Exit 1, kein Aufruf von `docker`, Punkte 4 und 8 nicht geprüft). Das Skript brauchte keine Änderung; der Fall `p2-nur-symlink` war an der unveränderten Kopie grün, die zwei Mutationen färben ihn. Weil weder Skript noch Fragment sich änderten, ist nach dem Fall kein neuer `make gates` gelaufen; der Lauf von oben (Skript und Fragment gleich) gilt. Gelaufen nach dem Fall: die volle `make workflows-check-gegenprobe` (grün, 83 Läufe) und `make docs-check` (0 Befunde).

### Findings des Reviews (`docs/reviews/2026-10-18-review-slice-harness-ci-workflows.md`) und ihr Ausgang

| ID | Ausgang |
|---|---|
| F-1 (MEDIUM) | behoben: Fälle `p8-dir-davor`, `p8-dir-danach`, `p8-modules-praefix`, `p8-modules-suffix`; Mutationen `m-p8-dir-ohne-block`, `m-p8-ohne-ruecksetzung`, `m-p8-modules-muster`, je rot gesehen |
| F-2 (MEDIUM) | behoben: Fälle `p9-verzeichnis-ohne-r` (Modus 311) und `p9-verzeichnis-ohne-x` (Modus 444) mit den Mutationen `m-p9-verzeichnis-r-fehlt` und `m-p9-verzeichnis-x-fehlt`; je Element der Prüfung `-r` und `-x` ein Fall |
| F-3 (MEDIUM) | behoben: als root entfallen die drei Fälle mit Rechten und ihre drei Mutationen, am Ende nennt die Gegenprobe sie auf stderr; die Gegenprobe lief als root im Container (`sudo -n`): grün, 97 Läufe, die sechs Namen stehen auf stderr |
| F-4 (LOW) | behoben: Fall `p5-form-ohne-regeln` (Tabulator plus Job ohne Zeitgrenze und ohne `permissions` oben: nur `form`), Mutation `m-p5-regeln-laufen` |
| F-5 (LOW) | behoben: Mutationen `m-p1-hinweis-endung-fehlt`, `m-p1-hinweis-grund-endung`, `m-p1-hinweis-unterverz-fehlt`, `m-p1-hinweis-grund-unterverz`, `m-p3-al-zeilen-veraendert`, `m-p3-stderr-anhang-fehlt` in der Tabelle; der Fall `p3-exit1` prüft jetzt die Ausgabe vollständig (der Vergleich mit `grep -F` über zwei Zeilen war zu schwach, `m-p3-al-zeilen-veraendert` blieb damit grün, bis er verschärft war) |
| F-6 (LOW) | behoben: Zeile in `harness/README.md` nennt die drei breiten Mutationen und das Verhalten als root |
| F-7 (LOW) | behoben: §6-Einleitung („vom Architect entschieden“) und DoD Liefer-Punkt 1 („Pfad, Zeile und Regel“) |
| F-8 (INFO) | Metrik oben neu gemessen |
| F-9 (INFO) | entfallen (Closure, Begründung in der Closure-Notiz): unverändert `export DOCKER` global; der Vertrag nennt die Schnittstelle (`DOCKER` aus `build.mk` als Umgebung des Skripts) und verlangt keinen engeren Export. Kopplung für den, der ein Skript ändert, das `DOCKER` aus der Umgebung liest. Ein zielgebundener Export (`target: export VAR`) kennt GNU make ohne Zuweisung nicht (am Gate gemessen: „No rule to make target export“) |
| F-10 (INFO, Architect) | umgesetzt nach `SPEC-063` Punkte 1 und 7: Skript prüft die Normalform (`^(0|[1-9][0-9]*)$`); Fälle `p7-fuehrende-null` (`010`, `0060`, `00`), `p7-vorzeichen`, `p7-dezimal`, `p1-symlink-andere-endung` mit je einer Mutation (zwei für den Symlink) |

**Offene Rückgabe:** keine. Der Befund im Review-Report (Kennungen ohne Link) ist mit `e9219f59` erledigt. Die Werkzeugliste im Kopf von `harness/mk/workflows.mk` (V-4) ist ergänzt; geändert ist nur eine Kommentar-Zeile, die Summe der Metrik bleibt 899.

### Verifikation (`docs/reviews/2026-10-18-verify-slice-harness-ci-workflows.md`) und ihr Ausgang

Urteil: bestanden, mit Auflagen vor der Closure. Liefer-Punkte 1 bis 3 bestätigt.

| ID | Ausgang |
|---|---|
| V-1 (mittel) | behoben: `make gates` am Integrationsstand `dffe1ccf` im Host-Worktree, Exit 0 (2026-10-18); der Nachweis des vollen Laufs ist geschrieben |
| V-2 (gering) | behoben (§7 *Belege des Implementers* nachgezogen, `dffe1ccf`) |
| V-3 (gering, CRLF) | weiter offen → `BEO-REPO/zeilenende-crlf-im-gelesenen-wert` (1×, ohne Adresse: kein Slice der Welle nimmt die Entscheidung an); Rückgabe an den Architect: in `SPEC-063` Punkt 5 das Zeilenende als Grenze nennen oder `\r` als Befund `form` einstufen |
| V-4 (gering) | behoben (Werkzeugliste im Kopf von `workflows.mk`, `bdfbedf5`) |
| V-5 (INFO) | Beleg in `BEO-REPO/groessenprobe-ohne-messbaren-stand`; künftige Pläne legen die Basis hinter den Commit des Architect, der den Vertrag setzt |

### Closure-Notiz

- **Was hat funktioniert:** Das Gate liegt vor der ersten Workflow-Datei; jede künftige Datei fällt vom ersten Commit an unter `actionlint`, die Regeln für `permissions` und `timeout-minutes` und die Bindung der Pin-Prüfung. Die Randformen standen vor dem Code in `SPEC-063` (zwölf, alle vom Architect entschieden), die Rückgaben während der Arbeit (Image-Herkunft, Rechte des Nicht-root-Images, Prüfbereich nur aus Symlinks) gingen an den Architect und nicht in den Code. Die Gegenprobe führt 99 Mutationen und 98 Fälle, davon drei gegen die echten Images; Review (0 HIGH, 3 MEDIUM) und Verifikation (25 Mutationen einzeln gefahren, das Skript vor und nach den Fixes verglichen) fanden keinen Defekt des Skripts, nur Lücken der Gegenprobe.
- **Was ging anders als geplant:** (1) Der Eintrag des Moduls `workflows` in `.d-check.yml` konnte nicht vor der ersten Datei stehen (das Modul meldet über leerer Prüfmenge einen Befund); er ging als Sendung an `slice-harness-ci` (§6 Randform 12). (2) Die Größe liegt bei 899 gegen die Schätzung 545 bis 695 (Faktor 1,3 bis 1,65), die Marke 900 ist um eine Zeile unterschritten; die Gegenprobe trug zwei Drittel. Der Planner rechnete daraufhin die Schätzung des Nachfolgers `slice-harness-ci` neu (ungeteilt 695 bis 1210, Mitte 920) und schnitt ihn vor dem Start (`slice-harness-ci-range-konfiguration`, Drift-Log der Roadmap). (3) Die drei MEDIUM-Befunde des Reviews gehören zur Klasse der 54 Slices davor: Elemente einer Aufzählung und Ortsangaben ohne Fall und Mutation je Element, dazu eine Überspringregel, die für den Fall galt und nicht für seine Mutation. (4) Zwei Basen der Metrik (899 und 891), weil ein Commit des Architect zwischen der Basis des Plans und dem Merge der Beauftragung liegt. (5) Der Review-Report trug drei Kennungen ohne Link und färbte `docs-check`; der Reviewer behob es.
- **Steering-Loop-Eintrag:** *neuer Sensor* und *benannte Spec-Lücke*. Sensor: das Gate `make workflows-check` mit seiner Gegenprobe `make workflows-check-gegenprobe` — liegt in `tools/harness/workflows-check.sh` und `harness/mk/workflows.mk` (`GATE_CHECKS`), die Gegenprobe in `tools/harness/workflows-check-gegenprobe.sh` (`GEGENPROBEN_CONTAINER`), Vertrag `SPEC-063`, Anker `· seit slice-harness-ci-workflows` in `harness/README.md` §Sensors. Es fängt die Klasse „Workflow-Datei ohne `permissions: {}`, ohne Zeitgrenze, mit Ausdrucksfehler oder ohne gebundene Pin-Prüfung“, die ohne das Gate erst ein Lauf auf GitHub gezeigt hätte. Spec-Lücke, offen: `SPEC-063` Punkt 5 nennt das Zeilenende der Eingabe nicht (CRLF ergibt einen Befund, der in die Irre führt); der Architect entscheidet (`BEO-REPO/zeilenende-crlf-im-gelesenen-wert`, 1×). Keine Regeländerung in `AGENTS.md`: Die Klasse der drei MEDIUM-Befunde hat eine Regel (`AGENTS.md` §3.10, Schärfung vom 2026-10-13) und steht im Register bei 55 Belegen (`BEO-REPO/negativtests-fehlen-bei-neuem-vertrag`, Sensor geplant: `slice-harness-mutation`).
- **Beobachtungs-Register (`../observations/`):** neu mit je einem Beleg `evidence/slice-harness-ci-workflows.md`: `BEO-REPO/workflow-pin-pruefung-am-gepinnten-d-check/` (Risiko 2; 1×, *weiter offen*) und `BEO-REPO/zeilenende-crlf-im-gelesenen-wert/` (V-3; 1×, offen). Weitere Belege gleichen Namens in `BEO-REPO/negativtests-fehlen-bei-neuem-vertrag/` (F-1, F-2, F-4, F-5; Zähler 55), `BEO-REPO/gegenprobe-haengt-an-umgebung-des-hosts/` (F-3, Benutzer root; Zähler 6, der Ausgang bleibt beim Nutzer), `BEO-REPO/zusage-im-kommentar-weiter-als-pruefung/` (F-6, V-4; 82), `BEO-REPO/plan-folgt-korrektur-nicht/` (F-7, V-2; 67), `BEO-REPO/schaetzung-in-zeilen-unterschaetzt-tests/` (F-8 und Faktor; 16, Stand `geplant` → `slice-harness-schaetzung-planner-faktor`) und `BEO-REPO/groessenprobe-ohne-messbaren-stand/` (V-5; 5). Die Klassen mit 3× und mehr haben einen Ausgang (`verkörpert` oder `geplant`) bis auf `gegenprobe-haengt-an-umgebung-des-hosts`: Sie stand schon vor diesem Slice bei 5× ohne Ausgang und wartet auf den Nutzer und die Welle-Closure von `welle-gegenproben-und-mutanten`. Kein neuer Folge-Slice entsteht aus diesem Slice.
- **Folge-Slices:** `slice-harness-ci-range-konfiguration` (Blöcke `commits` und `vcs` in `.d-check.yml` mit Gegenprobe — ist eine Datei in `open/`; Schnitt aus `slice-harness-ci`, keine Sendung dieses Slice) und `slice-harness-ci` (Eintrag des Moduls `workflows` in `.d-check.yml` mit `ci.yml` — ist eine Datei in `open/`; `grep -n slice-harness-ci-workflows` findet die Sendung in dessen §1, DoD Liefer-Punkt 1, §3 und §8 samt der Nachzählung nach dem Schnitt).
- **Risiken aus §6:**
  1. *Das Gate prüft eine Klasse, nicht die Lauffähigkeit* — entfallen: Die Grenze steht als akzeptiertes Negativ in `SPEC-063` Punkt 11 und in `SPEC-064` Punkt 5; der Auslöser des vorgesehenen Eintrags („`slice-harness-ci` trifft einen Lauf, den das Gate hätte fangen sollen“) ist nicht eingetreten, weil keine Workflow-Datei existiert. Tritt er ein, entsteht die Beobachtung bei der Closure von `slice-harness-ci` mit ihrem ersten Beleg (ein Verzeichnis ohne Auftreten wäre ein erfundener Beleg).
  2. *Der Pin-Check hängt am gepinnten d-check* — weiter offen → `BEO-REPO/workflow-pin-pruefung-am-gepinnten-d-check` (1×). Adresse der offenen Hälfte ist `slice-harness-ci` (setzt den Eintrag und prüft die Pins an `ci.yml`; Annahme geprüft nach `AGENTS.md` §3.13: §1 nennt den Eintrag unter „Übernommen von `slice-harness-ci-workflows`“, DoD Liefer-Punkt 1 verlangt ihn, §3 führt die Zeile, §6 führt das Risiko, §8 zählt nach). Das Gate zeigt am echten d-check `.yml` mit und ohne Version und Kommentar; nicht gezeigt sind `.yaml` und die Blockform von `uses:`.
  3. *`shellcheck` auf `run:`-Blöcke* — entfallen: `SPEC-063` Punkt 4 legt die Einstufung fest (jede Zeile von `actionlint` ist ein Befund, keine Option, keine Konfigurationsdatei), der Fall `p3-e8` und die Mutationen `m-p3-e8-ignore`, `m-p3-e8-pyflakes` und `m-p3-e8-shellcheck` zeigen es; ein Befund im `run:`-Block ist vom Schreiber der Datei zu beheben wie jeder andere.
  4. *Die Gegenprobe braucht das Image von `actionlint`* — entfallen: `make workflows-check-gegenprobe` steht in `GEGENPROBEN_CONTAINER` und ist kein Teil von `make gates`; `make workflows-check` selbst zieht das Image beim ersten Lauf (Pull-Limit des Docker Hub, von `SPEC-063` und [ADR-0050](../../adr/0050-ci-auf-github-actions.md) benannt).
- **Finding F-9** (INFO, `export DOCKER` global) — entfallen: Der Vertrag nennt `DOCKER` als Umgebung des Skripts, der Export steht allein in `harness/mk/workflows.mk` (`grep -rn "export DOCKER" harness/mk`), und ein zielgebundener Export ohne Zuweisung kennt GNU make nicht (am Gate gemessen, „No rule to make target export“); die Kopplung gilt für den, der ein Skript ändert, das `DOCKER` aus der Umgebung liest.
- **Drei Paarungen:** Anker: Der Sensor liegt in `tools/harness/workflows-check.sh`, `harness/mk/workflows.mk` und `tools/harness/workflows-check-gegenprobe.sh`, Anker `· seit slice-harness-ci-workflows` in `harness/README.md` §Sensors; eine Regel in `AGENTS.md` wird nicht verkörpert, `liegt in` dafür entfällt. Folge-Slice: `slice-harness-ci-range-konfiguration` und `slice-harness-ci` liegen in `open/` (siehe oben). Register: die Einträge oben, jedes Verzeichnis mit nicht leerem `evidence/`.
- **Rückgaben an den Architect:** (1) `SPEC-063` Punkt 5, Zeilenende (V-3). (2) `SPEC-064` Punkt 14: Teilung der Gegenprobe in ein Ziel für `ci.yml` und `ci-range.sh` und ein Ziel für die Konfiguration, vor dem Start von `slice-harness-ci-range-konfiguration`. (3) `SPEC-064` Punkt 14 und der Plan von `slice-harness-ci` widersprachen sich bei den Aufrufarten von `make` (der Plan verlangte Fälle für `-n`, `-q`, `-t`, `-i`, der Vertrag nennt keinen); der Plan folgt jetzt dem Vertrag.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien**.

**Vorgelagert — Sub-Area-Wahl prüfen:** Berührt ist die Default-Sub-Area `REPO` (`harness/conventions.md` §Modus-Deklaration pro Sub-Area), die einzige deklarierte; sie trägt eine einheitliche Greenfield-Deklaration, daher keine Ausdifferenzierung nötig.

**Vorgelagert — offene Beobachtungen sichten:** `docs/plan/planning/observations/BEO-REPO/` durchgesehen (Stand 2026-10-18). Treffer: `BEO-REPO/negativtests-fehlen-bei-neuem-vertrag` (`AGENTS.md` §3.10) und `BEO-REPO/spec-randform-erst-im-review-entschieden` (`AGENTS.md` §3.12) — das Gate ist ein neuer Vertrag, die Randformen stehen in §6 vor dem Code; `BEO-REPO/gate-laufzeit-waechst-mit-gegenprobe` — die Gegenprobe steht in der Container-Liste, nicht in der Kette; `BEO-REPO/gate-regel-ersetzt-statt-ergaenzt` — der Pin-Befund hat einen Ort (Randform 12). Kein Eintrag erreicht mit diesem Plan die Schwelle 3× neu.

**Modus-Begründungsblock:** alle berührten Sub-Areas GF.

**Zählung nach `AGENTS.md` §3.13 (Planner, 2026-10-18, im Commit, der den Plan anlegt):** Der Slice trägt keine Sendung eines Gebers. Liefer-Punkte 3 (Gate | Gegenprobe | Gate-Index). Schichten 1 (Harness: `harness/mk`, `tools/harness`, `harness/vertraege`, `harness/README.md`); Planung, Vertrag und ADR sind keine Schicht, Wartungs-Doku und Handbuch bleiben unberührt. Schätzung 455 bis 690 (§4), unter der Marke.

**Schätzung des Architect nach dem Vertrag (2026-10-18; Metrik von §4, `SPEC-063` und ADR vor dem Anspruch geschrieben und damit nicht gezählt):** `workflows-check.sh` 150 bis 190 (Prüfbereich, Aufruf von `actionlint`, Lesegrammatik, Rechte, Zeitgrenzen, Bindung, Ausgabe), `workflows.mk` 25, Gegenprobe das Doppelte des Produktcodes, 350 bis 450 (rund 75 Fälle, 40 Mutationen, drei echte Fälle), `harness/README.md` 20 bis 30, zusammen 545 bis 695, unter der Marke 900. Die Spanne des Planners (455 bis 690) enthielt den Vertrag; ohne ihn und mit der Gegenprobe nach den Punkten von `SPEC-063` liegt sie ähnlich. Die Gruppe (c) der Pins (`.d-check.yml`) entfällt aus diesem Slice (siehe §6, Randform 12) und mindert die Schätzung um rund 25.

**Nachzählung nach dem Vertrag (Planner, 2026-10-18; `AGENTS.md` §3.13):** Liefer-Punkte 3 (Gate | Gegenprobe | Gate-Index), Schichten 1; die Zeile `.d-check.yml` entfällt (Sendung an `slice-harness-ci`, dort gezählt), die Schätzung des Architect (545 bis 695, abzüglich rund 25) liegt unter der Marke 900.
